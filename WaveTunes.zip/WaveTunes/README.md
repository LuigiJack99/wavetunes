# WaveTunes

Local music player (Jetpack Compose, Material 3 / Material You, Media3) with:
- Wave equalizer at the bottom: live spectrum, tap/drag to seek, prev / play / next in the middle
- Playlists made inside the app (no Spotify needed): + on Home, or the ⋮ menu on any song
- Auto cover art: from the file, else looked up online (MusicBrainz + Cover Art Archive), else a generated cover
- Lyrics (word-by-word highlight is estimated; synced, tap a line to jump) from LRCLIB (lrclib.net), free, no key
- Customizable home screen: reorder, hide and resize blocks (Tune button, top right)
- Spotify playlist import: reads playlist track info and matches it to songs already on the phone

## Setup
Open in Android Studio, or push to GitHub: the included workflow (.github/workflows/build.yml)
builds a debug APK under Actions > Build APK.
No Spotify account keys or login are needed.

## Notes
- Import reads Spotify's public embed page for a PUBLIC playlist link. This is unofficial: it can
  break if Spotify changes the page, usually returns only the first ~100 tracks, and may go against
  Spotify's terms.
- Spotify audio can't be downloaded. Import matches tracks to music already on the phone
  (title + artist, then duration) and lists what wasn't found.
- The live wave needs the microphone permission (Android's Visualizer API). Without it, the wave
  shows an animated placeholder.
