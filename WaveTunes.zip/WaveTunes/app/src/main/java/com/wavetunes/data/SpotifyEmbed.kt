package com.wavetunes.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject

/**
 * Reads a PUBLIC playlist without any login by parsing Spotify's public embed page.
 * Unofficial: undocumented, may break whenever Spotify changes the page, and usually
 * returns only the first ~100 tracks.
 */
object SpotifyEmbed {
    private val http = OkHttpClient()
    private val idRegex = Regex("playlist[/:]([A-Za-z0-9]{22})")
    private val nextData = Regex(
        "<script id=\"__NEXT_DATA__\" type=\"application/json\">(.*?)</script>",
        RegexOption.DOT_MATCHES_ALL
    )

    /** Accepts https://open.spotify.com/playlist/<id>?si=..., spotify:playlist:<id>, or an embed link. */
    fun playlistId(link: String): String? = idRegex.find(link.trim())?.groupValues?.get(1)

    suspend fun fetch(id: String): Pair<String, List<SpotifyTrack>> = withContext(Dispatchers.IO) {
        val req = Request.Builder()
            .url("https://open.spotify.com/embed/playlist/$id")
            .header("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/124.0 Mobile Safari/537.36")
            .build()
        val html = http.newCall(req).execute().use { r ->
            if (!r.isSuccessful) error("Couldn't open that playlist (${r.code}). Is it public?")
            r.body!!.string()
        }
        val json = nextData.find(html)?.groupValues?.get(1)
            ?: error("Spotify changed its page format, so link import no longer works.")
        val holder = findParent(JSONObject(json), "trackList")
            ?: error("No tracks found. The playlist may be private or empty.")
        val arr = holder.getJSONArray("trackList")
        val tracks = List(arr.length()) { i ->
            val t = arr.getJSONObject(i)
            SpotifyTrack(
                name = t.optString("title"),
                artist = t.optString("subtitle").substringBefore(",").trim(),
                durationMs = t.optLong("duration"),
            )
        }.filter { it.name.isNotBlank() }
        val name = holder.optString("name").ifEmpty { holder.optString("title") }.ifEmpty { "Spotify playlist" }
        name to tracks
    }

    /** Finds the JSON object that directly contains [key], wherever it is nested. */
    private fun findParent(node: Any?, key: String): JSONObject? {
        when (node) {
            is JSONObject -> {
                if (node.has(key)) return node
                for (k in node.keys()) findParent(node.opt(k), key)?.let { return it }
            }
            is JSONArray -> for (i in 0 until node.length()) findParent(node.opt(i), key)?.let { return it }
        }
        return null
    }
}
