package com.wavetunes.data

import android.content.ContentUris
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import android.net.Uri
import android.provider.MediaStore
import androidx.compose.ui.graphics.toArgb

/** Bumped whenever a cover changes, so the notification / control center reloads the artwork. */
object ArtVersion { @Volatile var v = 0 }

/**
 * Artwork address used in the media notification and Android's media controls. It is resolved by
 * CoverBitmapLoader, so it works for covers from the file, found online, chosen by you, or generated.
 */
fun Song.artUri(): Uri = Uri.Builder().scheme("wavetunes").authority("cover").appendPath(id.toString())
    .appendQueryParameter("t", title).appendQueryParameter("a", artist)
    .appendQueryParameter("v", ArtVersion.v.toString()).build()

fun songFromArtUri(uri: Uri): Song? {
    val id = uri.lastPathSegment?.toLongOrNull() ?: return null
    return Song(
        id, uri.getQueryParameter("t") ?: "", uri.getQueryParameter("a") ?: "", "", 0L,
        ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id), Uri.EMPTY,
    )
}

/** The generated gradient cover as a real bitmap (for places that can't draw Compose). */
fun generatedBitmap(song: Song): Bitmap {
    val size = 512
    val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
    val base = generatedColor(song)
    val paint = Paint().apply {
        shader = LinearGradient(0f, 0f, size.toFloat(), size.toFloat(), base.toArgb(), shiftHue(base, 50f).toArgb(), Shader.TileMode.CLAMP)
    }
    Canvas(bmp).drawRect(0f, 0f, size.toFloat(), size.toFloat(), paint)
    return bmp
}

fun Bitmap.limitTo(max: Int): Bitmap =
    if (width <= max && height <= max) this
    else {
        val s = max.toFloat() / maxOf(width, height)
        Bitmap.createScaledBitmap(this, (width * s).toInt().coerceAtLeast(1), (height * s).toInt().coerceAtLeast(1), true)
    }
