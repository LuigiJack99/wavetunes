package com.wavetunes.ui

import android.graphics.Bitmap
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.BlurredEdgeTreatment
import androidx.compose.ui.draw.blur
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import com.wavetunes.data.AppSettings
import com.wavetunes.data.BgStyle
import com.wavetunes.data.WallpaperStore
import com.wavetunes.data.shiftHue
import androidx.compose.animation.Crossfade
import androidx.compose.runtime.produceState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin

private const val TWO_PI = (2 * PI).toFloat()

/** The app's live wallpaper: follows the album color; style, motion and strength come from Settings. */
@Composable
fun AlbumBackground(seed: Color?, art: Bitmap?, settings: AppSettings, wallpaper: String?, modifier: Modifier = Modifier) {
    val cs = MaterialTheme.colorScheme
    val tint by animateColorAsState(seed ?: cs.primary, tween(900), label = "bgTint")
    val strength = settings.bgIntensity
    val time = if (settings.bgAnimated) {
        val t by rememberInfiniteTransition(label = "bg").animateFloat(
            0f, TWO_PI, infiniteRepeatable(tween(24_000, easing = LinearEasing)), label = "bgT"
        )
        t
    } else 0.6f

    Box(modifier.background(cs.background)) {
        when (settings.bgStyle) {
            BgStyle.NONE -> {}
            BgStyle.GRADIENT -> Canvas(Modifier.fillMaxSize()) {
                val shift = sin(time) * size.height * 0.08f
                drawRect(
                    Brush.verticalGradient(
                        listOf(tint.copy(alpha = 0.65f * strength), cs.background),
                        startY = shift, endY = size.height + shift,
                    )
                )
            }
            BgStyle.AURORA -> Aurora(tint, time, strength)
            BgStyle.IMAGE -> WallpaperImage(wallpaper, strength) { Aurora(tint, time, strength) }
            BgStyle.COVER ->
                if (art != null) Box(Modifier.fillMaxSize()) {
                    Image(
                        art.asImageBitmap(), null,
                        Modifier.fillMaxSize().blur(40.dp, BlurredEdgeTreatment.Unbounded),
                        contentScale = ContentScale.Crop,
                    )
                    Box(Modifier.fillMaxSize().background(cs.background.copy(alpha = 1f - 0.6f * strength)))
                } else Aurora(tint, time, strength)
        }
    }
}

@Composable
private fun Aurora(tint: Color, t: Float, strength: Float) {
    val a = shiftHue(tint, 40f)
    val b = shiftHue(tint, -40f)
    Canvas(Modifier.fillMaxSize()) {
        val w = size.width; val h = size.height
        val r = max(w, h) * 0.65f
        fun blob(color: Color, cx: Float, cy: Float) = drawCircle(
            Brush.radialGradient(
                listOf(color.copy(alpha = 0.55f * strength), Color.Transparent),
                center = Offset(cx, cy), radius = r,
            ),
            radius = r, center = Offset(cx, cy),
        )
        blob(tint, w * (0.25f + 0.2f * sin(t)), h * (0.2f + 0.15f * cos(t * 1.3f)))
        blob(a, w * (0.75f + 0.2f * cos(t * 0.8f)), h * (0.5f + 0.2f * sin(t * 1.1f)))
        blob(b, w * (0.5f + 0.25f * sin(t * 1.7f)), h * (0.85f + 0.1f * cos(t)))
    }
}

/** Your own wallpaper image for the playing album's color; falls back when none is set. */
@Composable
private fun WallpaperImage(key: String?, strength: Float, fallback: @Composable () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val img by produceState<Bitmap?>(null, key) {
        value = key?.let { k -> withContext(Dispatchers.IO) { WallpaperStore.decodeFile(k.substringBefore('?'), 1600) } }
    }
    Crossfade(img, Modifier.fillMaxSize(), label = "wallpaper") { b ->
        if (b == null) fallback() else Box(Modifier.fillMaxSize()) {
            Image(b.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            Box(Modifier.fillMaxSize().background(cs.background.copy(alpha = 0.15f + 0.55f * (1f - strength))))
        }
    }
}
