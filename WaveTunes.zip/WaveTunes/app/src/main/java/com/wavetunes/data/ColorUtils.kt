package com.wavetunes.data

import android.graphics.Bitmap
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin

/** The main color of a cover: the strongest hue family, not a muddy average. Grays stay gray. */
fun dominantColor(b: Bitmap): Color {
    val n = 24
    val s = Bitmap.createScaledBitmap(b, n, n, true)
    val w = FloatArray(12); val sumS = FloatArray(12); val sumV = FloatArray(12)
    val hx = FloatArray(12); val hy = FloatArray(12)
    var gray = 0f
    val hsv = FloatArray(3)
    for (y in 0 until n) for (x in 0 until n) {
        android.graphics.Color.colorToHSV(s.getPixel(x, y), hsv)
        gray += hsv[2]
        if (hsv[1] < 0.15f || hsv[2] < 0.15f) continue
        val wt = hsv[1] * hsv[2]
        val bin = (((hsv[0] + 15f) % 360f) / 30f).toInt().coerceIn(0, 11)
        val rad = Math.toRadians(hsv[0].toDouble())
        w[bin] += wt; sumS[bin] += hsv[1] * wt; sumV[bin] += hsv[2] * wt
        hx[bin] += (cos(rad) * wt).toFloat(); hy[bin] += (sin(rad) * wt).toFloat()
    }
    if (w.sum() < n * n * 0.04f) return Color.hsv(0f, 0f, (gray / (n * n)).coerceIn(0.3f, 0.8f))
    val best = w.indices.maxByOrNull { w[it] }!!
    var hue = Math.toDegrees(atan2(hy[best].toDouble(), hx[best].toDouble())).toFloat()
    if (hue < 0) hue += 360f
    return Color.hsv(hue, (sumS[best] / w[best]).coerceIn(0.35f, 1f), (sumV[best] / w[best]).coerceIn(0.55f, 1f))
}

fun familyOf(c: Color): HueFamily {
    val hsv = FloatArray(3)
    android.graphics.Color.colorToHSV(c.toArgb(), hsv)
    if (hsv[1] < 0.15f) return HueFamily.NEUTRAL
    val h = hsv[0]
    return when {
        h < 15 || h >= 345 -> HueFamily.RED
        h < 45 -> HueFamily.ORANGE
        h < 70 -> HueFamily.YELLOW
        h < 165 -> HueFamily.GREEN
        h < 200 -> HueFamily.CYAN
        h < 255 -> HueFamily.BLUE
        h < 290 -> HueFamily.PURPLE
        else -> HueFamily.PINK
    }
}

/** Bright, saturated version for things drawn on dark backgrounds (visualizer, play button). */
fun brighten(c: Color): Color {
    val hsv = FloatArray(3)
    android.graphics.Color.colorToHSV(c.toArgb(), hsv)
    if (hsv[1] >= 0.15f) hsv[1] = hsv[1].coerceAtLeast(0.45f)
    hsv[2] = hsv[2].coerceAtLeast(0.9f)
    return Color(android.graphics.Color.HSVToColor(hsv))
}

fun shiftHue(c: Color, deg: Float): Color {
    val hsv = FloatArray(3)
    android.graphics.Color.colorToHSV(c.toArgb(), hsv)
    hsv[0] = ((hsv[0] + deg) % 360f + 360f) % 360f
    return Color(android.graphics.Color.HSVToColor(hsv))
}

/** Color for a song with no cover at all (matches its generated cover). */
fun generatedColor(song: Song): Color = Color.hsv((abs(song.title.hashCode()) % 360).toFloat(), 0.55f, 0.65f)
