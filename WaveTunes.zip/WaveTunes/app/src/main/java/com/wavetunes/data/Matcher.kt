package com.wavetunes.data

import kotlin.math.abs

/** Matches Spotify tracks to audio files already on the phone. */
object Matcher {
    private val brackets = Regex("\\(.*?\\)|\\[.*?]")
    private val junk = Regex("[^\\p{L}\\p{N}]")

    private fun norm(s: String) = s.lowercase()
        .replace(brackets, "")
        .substringBefore(" - ")      // "Song - Remastered 2011"
        .replace(junk, "")

    fun match(tracks: List<SpotifyTrack>, songs: List<Song>): Pair<List<Song>, List<SpotifyTrack>> {
        val byTitle = songs.groupBy { norm(it.title) }
        val found = mutableListOf<Song>()
        val missing = mutableListOf<SpotifyTrack>()
        for (t in tracks) {
            val candidates = byTitle[norm(t.name)].orEmpty()
            val ta = norm(t.artist)
            val hit = candidates.firstOrNull { val a = norm(it.artist); a.contains(ta) || ta.contains(a) }
                ?: candidates.firstOrNull { abs(it.durationMs - t.durationMs) < 3000 }
            if (hit != null) { if (hit !in found) found += hit } else missing += t
        }
        return found to missing
    }
}
