package com.wavetunes.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import java.io.File

/** The cover the user picked for a song (Settings > Image variants). */
object CoverStore {
    private fun dir(ctx: Context) = File(ctx.filesDir, "covers").apply { mkdirs() }
    private fun f(ctx: Context, song: Song, ext: String) = File(dir(ctx), "${song.id}.$ext")

    fun chosen(ctx: Context, song: Song): Bitmap? =
        f(ctx, song, "jpg").takeIf { it.exists() }?.let { BitmapFactory.decodeFile(it.path) }

    fun isGenerated(ctx: Context, song: Song) = f(ctx, song, "gen").exists()

    fun setImage(ctx: Context, song: Song, bmp: Bitmap) {
        f(ctx, song, "gen").delete(); f(ctx, song, "none").delete()
        f(ctx, song, "jpg").outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 92, it) }
    }

    fun setGenerated(ctx: Context, song: Song) {
        f(ctx, song, "jpg").delete()
        f(ctx, song, "gen").createNewFile()
    }

    /** Back to automatic: the file's own cover, else an online lookup. */
    fun reset(ctx: Context, song: Song) {
        listOf("jpg", "gen", "none").forEach { f(ctx, song, it).delete() }
    }
}
