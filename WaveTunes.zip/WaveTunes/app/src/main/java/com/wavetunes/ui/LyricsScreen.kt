package com.wavetunes.ui

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import com.wavetunes.AppViewModel
import com.wavetunes.data.Screen

@Composable
fun LyricsScreen(vm: AppViewModel, pad: PaddingValues, posMs: Long) {
    val lyrics by vm.lyrics.collectAsState()
    val loading by vm.lyricsLoading.collectAsState()
    val song by vm.nowPlaying.collectAsState()
    val cs = MaterialTheme.colorScheme

    Column(Modifier.padding(pad)) {
        Header(song?.title ?: "Lyrics") { vm.screen.value = Screen.Home }
        val l = lyrics
        when {
            song == null -> Message("Play a song to see its lyrics.")
            loading -> Box(Modifier.fillMaxWidth().padding(32.dp), Alignment.Center) { CircularProgressIndicator() }
            l == null -> Message("No lyrics found for this song. Check that its title and artist are correct.")
            else -> {
                val current = if (l.synced) l.lines.indexOfLast { it.timeMs <= posMs } else -1
                val state = rememberLazyListState()
                LaunchedEffect(current) { if (current >= 0) state.animateScrollToItem((current - 2).coerceAtLeast(0)) }
                LazyColumn(state = state, contentPadding = PaddingValues(horizontal = 24.dp, vertical = 24.dp)) {
                    itemsIndexed(l.lines) { i, line ->
                        val active = i == current
                        val scale by animateFloatAsState(if (active) 1f else 0.88f, tween(300), label = "lineScale")
                        val end = l.lines.getOrNull(i + 1)?.timeMs ?: (line.timeMs + 4000)
                        val text = if (active) wordSynced(line.text, line.timeMs, end, posMs, cs.onSurface)
                                   else AnnotatedString(line.text)
                        Text(
                            text,
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = if (active) FontWeight.Bold else FontWeight.Normal,
                            color = if (!l.synced) cs.onSurface else cs.onSurface.copy(alpha = 0.45f),
                            modifier = Modifier.fillMaxWidth()
                                .graphicsLayer { scaleX = scale; scaleY = scale; transformOrigin = TransformOrigin(0f, 0.5f) }
                                .clickable(enabled = l.synced) { vm.seekToMs(line.timeMs) }
                                .padding(vertical = 8.dp),
                        )
                    }
                }
            }
        }
    }
}

/**
 * Word-by-word highlight. The lyrics source only has a timestamp per LINE, so the words are
 * timed by estimate: the line's time is shared between its words by their length.
 */
private fun wordSynced(text: String, startMs: Long, endMs: Long, posMs: Long, color: Color): AnnotatedString {
    val words = text.split(" ")
    val weights = words.map { it.length.coerceAtLeast(1) }
    val total = weights.sum()
    val duration = minOf((endMs - startMs).coerceAtLeast(1), maxOf(1500L, text.length * 90L))
    val reached = ((posMs - startMs).toFloat() / duration).coerceIn(0f, 1f) * total
    return buildAnnotatedString {
        var acc = 0
        words.forEachIndexed { i, w ->
            val wp = ((reached - acc) / weights[i]).coerceIn(0f, 1f)
            acc += weights[i]
            withStyle(SpanStyle(color = color.copy(alpha = 0.45f + 0.55f * wp))) { append(w) }
            if (i < words.lastIndex) append(" ")
        }
    }
}

@Composable
private fun Message(text: String) {
    Text(text, Modifier.padding(24.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
}
