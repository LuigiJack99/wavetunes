package com.wavetunes.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.wavetunes.AppViewModel
import com.wavetunes.data.Screen

@Composable
fun LyricsScreen(vm: AppViewModel, pad: PaddingValues, posMs: Long) {
    val lyrics by vm.lyrics.collectAsState()
    val loading by vm.lyricsLoading.collectAsState()
    val song by vm.nowPlaying.collectAsState()
    val cs = MaterialTheme.colorScheme

    Column(Modifier.padding(pad)) {
        Header(song?.title ?: "Lyrics") { vm.screen.value = Screen.Home }
        val l = lyrics
        when {
            song == null -> Message("Play a song to see its lyrics.")
            loading -> Box(Modifier.fillMaxWidth().padding(32.dp), Alignment.Center) { CircularProgressIndicator() }
            l == null -> Message("No lyrics found for this song. Check that its title and artist are correct.")
            else -> {
                val current = if (l.synced) l.lines.indexOfLast { it.timeMs <= posMs } else -1
                val state = rememberLazyListState()
                LaunchedEffect(current) { if (current >= 0) state.animateScrollToItem((current - 2).coerceAtLeast(0)) }
                LazyColumn(state = state, contentPadding = PaddingValues(horizontal = 24.dp, vertical = 24.dp)) {
                    itemsIndexed(l.lines) { i, line ->
                        val active = i == current
                        Text(
                            line.text,
                            style = if (active) MaterialTheme.typography.headlineSmall else MaterialTheme.typography.titleLarge,
                            fontWeight = if (active) FontWeight.Bold else FontWeight.Normal,
                            color = if (active || !l.synced) cs.onSurface else cs.onSurface.copy(alpha = 0.45f),
                            modifier = Modifier.fillMaxWidth()
                                .clickable(enabled = l.synced) { vm.seekToMs(line.timeMs) }
                                .padding(vertical = 8.dp),
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun Message(text: String) {
    Text(text, Modifier.padding(24.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
}
