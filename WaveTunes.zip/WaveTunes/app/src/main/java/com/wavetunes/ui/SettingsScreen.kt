package com.wavetunes.ui

import android.app.WallpaperManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.border
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.wavetunes.AppViewModel
import com.wavetunes.data.*
import com.wavetunes.wallpaper.WaveWallpaperService

private val swatches = listOf(
    0xFFE53935L, 0xFFFB8C00L, 0xFFFDD835L, 0xFF43A047L, 0xFF00ACC1L,
    0xFF1E88E5L, 0xFF8E24AAL, 0xFFD81B60L, 0xFF9E9E9EL,
).map { it.toInt() }

@Composable
fun SettingsScreen(vm: AppViewModel, pad: PaddingValues) {
    val s by vm.settings.collectAsState()
    val ctx = LocalContext.current
    fun update(f: (AppSettings) -> AppSettings) = vm.updateSettings(f)
    var pending by remember { mutableStateOf<HueFamily?>(null) }
    var addingRule by remember { mutableStateOf(false) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        val fam = pending; pending = null
        if (uri != null && fam != null) vm.setWallpaper(fam, uri)
    }

    Column(Modifier.padding(pad)) {
        Header("Settings") { vm.back() }
        Column(
            Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 20.dp).padding(bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            ListItem(
                modifier = Modifier.clip(MaterialTheme.shapes.large).clickable { vm.screen.value = Screen.Variants },
                headlineContent = { Text("Image variants") },
                supportingContent = { Text("Pick a different cover for any song") },
                leadingContent = { Icon(Icons.Rounded.Image, null) },
                trailingContent = { Icon(Icons.Rounded.ChevronRight, null) },
            )

            Section("Theme")
            Label("Mode")
            ChipRow(listOf(ThemeMode.SYSTEM to "System", ThemeMode.LIGHT to "Light", ThemeMode.DARK to "Dark"), s.themeMode) { m ->
                update { it.copy(themeMode = m) }
            }
            Label("Colors from")
            ChipRow(
                listOf(ColorSource.ALBUM to "Album cover", ColorSource.SYSTEM to "Material You", ColorSource.CUSTOM to "Custom"),
                s.colorSource,
            ) { c -> update { it.copy(colorSource = c) } }
            if (s.colorSource == ColorSource.CUSTOM) {
                SwatchRow(selected = s.customColor, allowAuto = false) { c -> if (c != null) update { it.copy(customColor = c) } }
            }

            Section("In-app wallpaper")
            ChipRow(
                listOf(BgStyle.NONE to "None", BgStyle.GRADIENT to "Gradient", BgStyle.AURORA to "Aurora", BgStyle.COVER to "Blurred cover", BgStyle.IMAGE to "My wallpaper"),
                s.bgStyle,
            ) { b -> update { it.copy(bgStyle = b) } }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Animate", Modifier.weight(1f))
                Switch(checked = s.bgAnimated, onCheckedChange = { v -> update { it.copy(bgAnimated = v) } })
            }
            Label("Strength")
            Slider(value = s.bgIntensity, onValueChange = { v -> update { it.copy(bgIntensity = v) } })

            Section("Visualizer")
            ChipRow(listOf(24 to "24 bars", 48 to "48 bars", 72 to "72 bars"), s.barCount) { n -> update { it.copy(barCount = n) } }

            Section("Color rules")
            Text(
                "If an album cover is mostly one color, use the color you pick here for the theme and wallpapers. Auto uses the cover's own color.",
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            HueFamily.entries.forEach { fam ->
                Label("${fam.label} covers")
                SwatchRow(selected = s.hueOverrides[fam], allowAuto = true) { c ->
                    update { st -> st.copy(hueOverrides = if (c == null) st.hueOverrides - fam else st.hueOverrides + (fam to c)) }
                }
            }

            Section("Cover rules")
            Text(
                "For these artists, if a song has a re-recording from that year, its cover is used instead of the original album's.",
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            s.yearRules.forEach { (artist, year) ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("${artist.replaceFirstChar { it.uppercase() }} · $year", Modifier.weight(1f))
                    TextButton(onClick = { update { st -> st.copy(yearRules = st.yearRules - artist) } }) { Text("Remove") }
                }
            }
            TextButton(onClick = { addingRule = true }) { Text("Add rule") }
            if (addingRule) RuleDialog(onDismiss = { addingRule = false }) { artist, year ->
                update { st -> st.copy(yearRules = st.yearRules + (artist.trim().lowercase() to year)) }
                addingRule = false
            }

            Section("My wallpapers by album color")
            Text(
                "Pick your own image for each color. When the playing album is mostly that color, that image becomes your wallpaper: in the app (style \"My wallpaper\") and in the WaveTunes live wallpaper.",
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            HueFamily.entries.forEach { fam ->
                val name = s.wallpapers[fam]
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("${fam.label} covers", style = MaterialTheme.typography.labelLarge)
                        Text(
                            name ?: "Not set", style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis,
                        )
                    }
                    TextButton(onClick = {
                        pending = fam
                        picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                    }) { Text(if (name == null) "Choose" else "Change") }
                    if (name != null) TextButton(onClick = { vm.clearWallpaper(fam) }) { Text("Remove") }
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Set as my phone wallpaper")
                    Text(
                        "Changes your home and lock screen wallpaper when the album's color changes. This replaces your current wallpaper, including any live wallpaper. Colors with no image set leave it unchanged.",
                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                Switch(checked = s.systemWallpaper, onCheckedChange = { v -> update { it.copy(systemWallpaper = v) } })
            }

            Section("System live wallpaper")
            Text(
                "A real Android live wallpaper that fades to the color of the album you're playing. It uses the animation and strength settings above.",
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            ChipRow(listOf(BgStyle.GRADIENT to "Gradient", BgStyle.AURORA to "Aurora"), s.wpStyle) { b -> update { it.copy(wpStyle = b) } }
            Button(onClick = { openLiveWallpaper(ctx) }) { Text("Set live wallpaper") }
        }
    }
}

private fun openLiveWallpaper(ctx: Context) {
    val comp = ComponentName(ctx, WaveWallpaperService::class.java)
    val intent = Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER)
        .putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT, comp)
    try { ctx.startActivity(intent) } catch (e: Exception) {
        runCatching { ctx.startActivity(Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    }
}

@Composable
private fun Section(text: String) {
    Spacer(Modifier.height(8.dp))
    Text(text, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
}

@Composable
private fun Label(text: String) = Text(text, style = MaterialTheme.typography.labelLarge)

@Composable
private fun <T> ChipRow(options: List<Pair<T, String>>, selected: T, onSelect: (T) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEach { (value, label) ->
            FilterChip(selected = value == selected, onClick = { onSelect(value) }, label = { Text(label) })
        }
    }
}

@Composable
private fun SwatchRow(selected: Int?, allowAuto: Boolean, onSelect: (Int?) -> Unit) {
    val cs = MaterialTheme.colorScheme
    Row(
        Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically,
    ) {
        if (allowAuto) Box(
            Modifier.size(36.dp).clip(CircleShape)
                .border(if (selected == null) 3.dp else 1.dp, if (selected == null) cs.primary else cs.outline, CircleShape)
                .clickable { onSelect(null) },
            contentAlignment = Alignment.Center,
        ) { Text("Auto", style = MaterialTheme.typography.labelSmall) }
        swatches.forEach { c ->
            Box(
                Modifier.size(36.dp).clip(CircleShape).background(Color(c))
                    .border(if (selected == c) 3.dp else 0.dp, cs.onSurface, CircleShape)
                    .clickable { onSelect(c) }
            )
        }
    }
}

@Composable
private fun RuleDialog(onDismiss: () -> Unit, onAdd: (String, Int) -> Unit) {
    var artist by remember { mutableStateOf("") }
    var year by remember { mutableStateOf("2024") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("New cover rule") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(artist, { artist = it }, label = { Text("Artist") }, singleLine = true)
                OutlinedTextField(
                    year, { year = it.filter(Char::isDigit).take(4) },
                    label = { Text("Prefer versions from year") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                )
            }
        },
        confirmButton = {
            TextButton(onClick = { onAdd(artist, year.toInt()) }, enabled = artist.isNotBlank() && year.length == 4) { Text("Add") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}
