package com.wavetunes.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.wavetunes.AppViewModel
import com.wavetunes.data.*

@Composable
fun HomeScreen(vm: AppViewModel, pad: PaddingValues) {
    val layout by vm.layout.collectAsState()
    val editing by vm.editing.collectAsState()
    val songs by vm.songs.collectAsState()
    val playlists by vm.playlists.collectAsState()
    val shown = layout.withIndex().filter { it.value.visible || editing }

    LazyVerticalGrid(
        columns = GridCells.Fixed(2),
        contentPadding = PaddingValues(16.dp, pad.calculateTopPadding() + 8.dp, 16.dp, pad.calculateBottomPadding() + 16.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item(span = { GridItemSpan(2) }) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Home", style = MaterialTheme.typography.headlineLarge)
                    if (editing) Text(
                        "Move, hide or resize each block",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                FilledTonalIconButton(onClick = { vm.editing.value = !editing }) {
                    Icon(if (editing) Icons.Rounded.Check else Icons.Rounded.Tune, if (editing) "Done" else "Customize home")
                }
            }
        }
        items(shown, key = { it.value.type }, span = { GridItemSpan(if (it.value.full) 2 else 1) }) { (idx, block) ->
            BlockCard(vm, idx, block, editing, songs, playlists, Modifier.animateItem())
        }
    }
}

@Composable
private fun BlockCard(
    vm: AppViewModel, idx: Int, block: HomeBlock, editing: Boolean,
    songs: List<Song>, playlists: List<LocalPlaylist>, modifier: Modifier = Modifier,
) {
    val cs = MaterialTheme.colorScheme
    Card(
        shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.cardColors(containerColor = cs.surfaceContainerHigh),
        modifier = modifier.fillMaxWidth().alpha(if (block.visible) 1f else 0.4f),
    ) {
        Column(Modifier.padding(16.dp)) {
            if (editing) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    IconButton(onClick = { vm.moveBlock(idx, -1) }) { Icon(Icons.Rounded.ArrowUpward, "Move up") }
                    IconButton(onClick = { vm.moveBlock(idx, 1) }) { Icon(Icons.Rounded.ArrowDownward, "Move down") }
                    IconButton(onClick = { vm.resizeBlock(idx) }) {
                        Icon(if (block.full) Icons.Rounded.GridView else Icons.Rounded.ViewAgenda, "Resize")
                    }
                    IconButton(onClick = { vm.toggleBlock(idx) }) {
                        Icon(if (block.visible) Icons.Rounded.Visibility else Icons.Rounded.VisibilityOff, "Show or hide")
                    }
                }
            }
            val tap = !editing
            when (block.type) {
                BlockType.SHUFFLE -> Row(
                    Modifier.fillMaxWidth().clickable(enabled = tap) { vm.playShuffled() },
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    Icon(Icons.Rounded.Shuffle, null, tint = cs.primary, modifier = Modifier.size(32.dp))
                    Column {
                        Text("Shuffle all", style = MaterialTheme.typography.titleMedium)
                        Text("${songs.size} songs", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                    }
                }

                BlockType.RECENT -> Column {
                    Text("Recently added", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(10.dp))
                    if (songs.isEmpty()) Text("No music found on this phone yet.", style = MaterialTheme.typography.bodySmall)
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        songs.take(10).forEachIndexed { i, s ->
                            Column(Modifier.width(96.dp).clickable(enabled = tap) { vm.play(songs, i) }) {
                                SongArt(s, 96.dp, corner = 16.dp)
                                Text(s.title, style = MaterialTheme.typography.labelMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                        }
                    }
                }

                BlockType.PLAYLISTS -> Column {
                    var creating by remember { mutableStateOf(false) }
                    Text("Your playlists", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(6.dp))
                    if (playlists.isEmpty()) Text(
                        "No playlists yet. Make one, or import from a Spotify link.",
                        style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant,
                    )
                    playlists.take(4).forEach { p ->
                        Row(
                            Modifier.fillMaxWidth().clickable(enabled = tap) { vm.screen.value = Screen.Playlist(p.id) }.padding(vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Icon(Icons.Rounded.QueueMusic, null, tint = cs.primary)
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(p.name, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text("${p.songIds.size} songs", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                            }
                        }
                    }
                    TextButton(onClick = { creating = true }, enabled = tap) {
                        Icon(Icons.Rounded.Add, null)
                        Spacer(Modifier.width(6.dp))
                        Text("New playlist")
                    }
                    if (creating) NewPlaylistDialog(onDismiss = { creating = false }) { name ->
                        creating = false
                        vm.screen.value = Screen.Playlist(vm.createPlaylist(name))
                    }
                }

                BlockType.SPOTIFY -> Column {
                    Text("Spotify", style = MaterialTheme.typography.titleMedium)
                    Text(
                        "Paste a playlist link to match it to songs on your phone.",
                        style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant,
                    )
                    Spacer(Modifier.height(10.dp))
                    Button(onClick = { vm.screen.value = Screen.Import }, enabled = tap) { Text("Import playlist") }
                }

                BlockType.SONGS -> Column {
                    Text("All songs", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(4.dp))
                    songs.take(5).forEachIndexed { i, s ->
                        Column(Modifier.fillMaxWidth().clickable(enabled = tap) { vm.play(songs, i) }.padding(vertical = 6.dp)) {
                            Text(s.title, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(s.artist, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                    TextButton(onClick = { vm.screen.value = Screen.Library }, enabled = tap) { Text("See all") }
                }
            }
        }
    }
}
