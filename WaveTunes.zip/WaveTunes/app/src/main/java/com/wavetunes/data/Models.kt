package com.wavetunes.data

import android.net.Uri
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata

data class Song(
    val id: Long,
    val title: String,
    val artist: String,
    val album: String,
    val durationMs: Long,
    val uri: Uri,
    val art: Uri,
) {
    fun toMediaItem(): MediaItem = MediaItem.Builder()
        .setMediaId(id.toString())
        .setUri(uri)
        .setMediaMetadata(
            MediaMetadata.Builder()
                .setTitle(title).setArtist(artist).setAlbumTitle(album).setArtworkUri(artUri())
                .build()
        ).build()
}

data class SpotifyTrack(val name: String, val artist: String, val durationMs: Long) {
    val label get() = "$name — $artist"
}

data class LocalPlaylist(val id: String, val name: String, val songIds: List<Long>)

/** Blocks the user can reorder, hide and resize on the home screen. */
enum class BlockType { SHUFFLE, RECENT, PLAYLISTS, SPOTIFY, SONGS }

data class HomeBlock(val type: BlockType, val visible: Boolean = true, val full: Boolean = true)

data class ImportUi(
    val busy: Boolean = false,
    val message: String? = null,
    val missing: List<String> = emptyList(),
)

sealed interface Screen {
    data object Home : Screen
    data object Library : Screen
    data object Import : Screen
    data object Lyrics : Screen
    data object Settings : Screen
    data object Variants : Screen
    data class VariantPicker(val songId: Long) : Screen
    data class Playlist(val id: String) : Screen
}

enum class ThemeMode { SYSTEM, LIGHT, DARK }
enum class ColorSource { ALBUM, SYSTEM, CUSTOM }
enum class BgStyle { NONE, GRADIENT, AURORA, COVER, IMAGE }

enum class HueFamily(val label: String) {
    RED("Red"), ORANGE("Orange"), YELLOW("Yellow"), GREEN("Green"), CYAN("Cyan"),
    BLUE("Blue"), PURPLE("Purple"), PINK("Pink"), NEUTRAL("Gray / neutral")
}

data class AppSettings(
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val colorSource: ColorSource = ColorSource.ALBUM,
    val customColor: Int = 0xFF8E24AA.toInt(),
    val bgStyle: BgStyle = BgStyle.AURORA,
    val bgAnimated: Boolean = true,
    val bgIntensity: Float = 0.6f,
    val wpStyle: BgStyle = BgStyle.AURORA,          // style of the system live wallpaper
    val barCount: Int = 48,
    /** "If the cover is mostly <family>, use this color instead." */
    val hueOverrides: Map<HueFamily, Int> = emptyMap(),
    /** Your own wallpaper image per album color family: family -> file name shown in Settings. */
    val wallpapers: Map<HueFamily, String> = emptyMap(),
    /** artist (lowercase) -> year. Prefer that artist's releases from that year for covers. */
    val yearRules: Map<String, Int> = mapOf("weezer" to 2024),
)
