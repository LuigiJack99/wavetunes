package com.wavetunes.data

import android.net.Uri
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata

data class Song(
    val id: Long,
    val title: String,
    val artist: String,
    val album: String,
    val durationMs: Long,
    val uri: Uri,
    val art: Uri,
) {
    fun toMediaItem(): MediaItem = MediaItem.Builder()
        .setMediaId(id.toString())
        .setUri(uri)
        .setMediaMetadata(
            MediaMetadata.Builder()
                .setTitle(title).setArtist(artist).setAlbumTitle(album).setArtworkUri(art)
                .build()
        ).build()
}

data class SpotifyTrack(val name: String, val artist: String, val durationMs: Long) {
    val label get() = "$name — $artist"
}

data class LocalPlaylist(val id: String, val name: String, val songIds: List<Long>)

/** Blocks the user can reorder, hide and resize on the home screen. */
enum class BlockType { SHUFFLE, RECENT, PLAYLISTS, SPOTIFY, SONGS }

data class HomeBlock(val type: BlockType, val visible: Boolean = true, val full: Boolean = true)

data class ImportUi(
    val busy: Boolean = false,
    val message: String? = null,
    val missing: List<String> = emptyList(),
)

sealed interface Screen {
    data object Home : Screen
    data object Library : Screen
    data object Import : Screen
    data class Playlist(val id: String) : Screen
}
