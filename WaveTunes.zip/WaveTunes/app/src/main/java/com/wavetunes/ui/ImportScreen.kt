package com.wavetunes.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.wavetunes.AppViewModel
import com.wavetunes.data.Screen

@Composable
fun ImportScreen(vm: AppViewModel, pad: PaddingValues) {
    val ui by vm.importUi.collectAsState()
    var link by remember { mutableStateOf("") }
    val cs = MaterialTheme.colorScheme

    Column(Modifier.padding(pad).verticalScroll(rememberScrollState())) {
        Header("Import from Spotify") { vm.screen.value = Screen.Home }
        Column(Modifier.padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(
                "Paste a link to a public playlist. Spotify doesn't share audio, so each song is matched to a file already on this phone.",
                style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant,
            )
            OutlinedTextField(
                value = link, onValueChange = { link = it },
                label = { Text("Playlist link") }, singleLine = true,
                modifier = Modifier.fillMaxWidth(),
            )
            Button(onClick = { vm.importLink(link) }, enabled = link.isNotBlank() && !ui.busy) { Text("Import playlist") }
            if (ui.busy) LinearProgressIndicator(Modifier.fillMaxWidth())
            ui.message?.let { Text(it, color = cs.primary) }
            if (ui.missing.isNotEmpty()) {
                Text("Not found on this phone", style = MaterialTheme.typography.titleSmall)
                ui.missing.take(20).forEach { Text(it, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant) }
                if (ui.missing.size > 20) Text("and ${ui.missing.size - 20} more", style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}
