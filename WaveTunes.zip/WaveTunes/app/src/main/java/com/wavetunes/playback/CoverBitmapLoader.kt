package com.wavetunes.playback

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import androidx.media3.common.util.BitmapLoader
import androidx.media3.datasource.DataSourceBitmapLoader
import com.google.common.util.concurrent.ListenableFuture
import com.google.common.util.concurrent.SettableFuture
import com.wavetunes.data.generatedBitmap
import com.wavetunes.data.limitTo
import com.wavetunes.data.songFromArtUri
import com.wavetunes.ui.songBitmap
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch

/**
 * Gives the notification, lock screen and Android's media controls the real cover of the playing
 * song: the one from the file, found online, picked by you in Image variants, or generated.
 */
class CoverBitmapLoader(private val ctx: Context, private val scope: CoroutineScope) : BitmapLoader {
    private val fallback = DataSourceBitmapLoader(ctx)

    override fun supportsMimeType(mimeType: String) = fallback.supportsMimeType(mimeType)
    override fun decodeBitmap(data: ByteArray) = fallback.decodeBitmap(data)

    override fun loadBitmap(uri: Uri): ListenableFuture<Bitmap> {
        if (uri.scheme != "wavetunes") return fallback.loadBitmap(uri)
        val future = SettableFuture.create<Bitmap>()
        scope.launch {
            try {
                val song = songFromArtUri(uri)
                if (song == null) future.setException(IllegalArgumentException("Bad cover address"))
                else future.set((songBitmap(ctx, song) ?: generatedBitmap(song)).limitTo(512))
            } catch (e: Exception) {
                future.setException(e)
            }
        }
        return future
    }
}
