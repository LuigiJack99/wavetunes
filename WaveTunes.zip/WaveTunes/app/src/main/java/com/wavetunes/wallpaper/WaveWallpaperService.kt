package com.wavetunes.wallpaper

import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.os.Handler
import android.os.Looper
import android.service.wallpaper.WallpaperService
import android.view.SurfaceHolder
import androidx.core.graphics.ColorUtils
import com.wavetunes.data.WALLPAPER_PREFS
import com.wavetunes.data.WallpaperStore
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * Real Android live wallpaper. Shows your own wallpaper image for the playing album's color
 * (Settings > My wallpapers); with none set it shows an animated gradient/aurora in the album color.
 * Everything fades when the song changes.
 */
class WaveWallpaperService : WallpaperService() {
    override fun onCreateEngine(): Engine = WaveEngine()

    inner class WaveEngine : Engine() {
        private val handler = Handler(Looper.getMainLooper())
        private val prefs = getSharedPreferences(WALLPAPER_PREFS, MODE_PRIVATE)
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val imgPaint = Paint(Paint.FILTER_BITMAP_FLAG)
        private val matrix = Matrix()
        private var visible = false
        private var t = 0f
        private var cur = 0xFF3A3A3A.toInt()
        private var target = cur
        private var style = "AURORA"
        private var animated = true
        private var intensity = 0.6f
        private var imageKey = ""
        private var bmp: Bitmap? = null
        private var prev: Bitmap? = null
        private var fade = 1f

        private val listener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ -> read(); restart() }
        private val tick = object : Runnable {
            override fun run() { drawFrame(); if (visible && animating()) handler.postDelayed(this, 33) }
        }

        private fun read() {
            target = prefs.getInt("color", target)
            style = prefs.getString("style", style) ?: style
            animated = prefs.getBoolean("animated", animated)
            intensity = prefs.getFloat("intensity", intensity)
            val key = prefs.getString("image", "") ?: ""
            if (key != imageKey) {
                imageKey = key
                prev = bmp
                val dm = resources.displayMetrics
                bmp = if (key.isEmpty()) null
                      else WallpaperStore.decodeFile(key.substringBefore('?'), max(dm.widthPixels, dm.heightPixels))
                fade = 0f
            }
        }

        private fun restart() {
            if (visible) { handler.removeCallbacks(tick); handler.post(tick) }
        }

        /** A still image needs no redraws. Gradient/aurora only redraw while animating or fading. */
        private fun animating(): Boolean =
            if (bmp != null) fade < 1f else (animated || cur != target || fade < 1f)

        private fun colorClose(a: Int, b: Int) =
            abs(Color.red(a) - Color.red(b)) < 3 && abs(Color.green(a) - Color.green(b)) < 3 && abs(Color.blue(a) - Color.blue(b)) < 3

        override fun onCreate(holder: SurfaceHolder) {
            super.onCreate(holder)
            prefs.registerOnSharedPreferenceChangeListener(listener)
            read(); cur = target; fade = 1f; prev = null
        }

        override fun onVisibilityChanged(visible: Boolean) {
            this.visible = visible
            handler.removeCallbacks(tick)
            if (visible) handler.post(tick)
        }

        override fun onSurfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
            super.onSurfaceChanged(holder, format, width, height)
            drawFrame()
        }

        override fun onSurfaceRedrawNeeded(holder: SurfaceHolder) { drawFrame() }

        override fun onDestroy() {
            visible = false
            handler.removeCallbacks(tick)
            prefs.unregisterOnSharedPreferenceChangeListener(listener)
            super.onDestroy()
        }

        private fun shift(color: Int, deg: Float): Int {
            val hsv = FloatArray(3); Color.colorToHSV(color, hsv)
            hsv[0] = ((hsv[0] + deg) % 360f + 360f) % 360f
            return Color.HSVToColor(hsv)
        }

        private fun drawCover(c: Canvas, b: Bitmap, alpha: Int) {
            val w = c.width.toFloat(); val h = c.height.toFloat()
            val s = max(w / b.width, h / b.height)
            matrix.reset()
            matrix.postScale(s, s)
            matrix.postTranslate((w - b.width * s) / 2f, (h - b.height * s) / 2f)
            imgPaint.alpha = alpha.coerceIn(0, 255)
            c.drawBitmap(b, matrix, imgPaint)
        }

        private fun drawFrame() {
            val c = surfaceHolder.lockCanvas() ?: return
            try {
                cur = ColorUtils.blendARGB(cur, target, 0.06f)       // smooth fade between songs
                if (colorClose(cur, target)) cur = target
                if (animated) t += 0.012f
                if (fade < 1f) { fade = min(1f, fade + 0.05f); if (fade >= 1f) prev = null }
                val w = c.width.toFloat(); val h = c.height.toFloat()
                val hsv = FloatArray(3); Color.colorToHSV(cur, hsv)
                val bg = Color.HSVToColor(floatArrayOf(hsv[0], hsv[1] * 0.5f, 0.10f))
                c.drawColor(bg)

                val imageOnly = bmp != null && fade >= 1f
                if (!imageOnly) {
                    val alpha = (140 * intensity + 40).toInt().coerceIn(0, 255)
                    if (style == "GRADIENT") {
                        paint.shader = LinearGradient(0f, 0f, 0f, h, ColorUtils.setAlphaComponent(cur, alpha), bg, Shader.TileMode.CLAMP)
                        c.drawRect(0f, 0f, w, h, paint)
                    } else {
                        val r = max(w, h) * 0.65f
                        fun blob(color: Int, cx: Float, cy: Float) {
                            paint.shader = RadialGradient(cx, cy, r, ColorUtils.setAlphaComponent(color, alpha), Color.TRANSPARENT, Shader.TileMode.CLAMP)
                            c.drawCircle(cx, cy, r, paint)
                        }
                        blob(cur, w * (0.25f + 0.2f * sin(t)), h * (0.2f + 0.15f * cos(t * 1.3f)))
                        blob(shift(cur, 40f), w * (0.75f + 0.2f * cos(t * 0.8f)), h * (0.5f + 0.2f * sin(t * 1.1f)))
                        blob(shift(cur, -40f), w * (0.5f + 0.25f * sin(t * 1.7f)), h * (0.85f + 0.1f * cos(t)))
                    }
                    paint.shader = null
                }
                prev?.let { drawCover(c, it, ((1f - fade) * 255).toInt()) }
                bmp?.let { drawCover(c, it, (fade * 255).toInt()) }
            } finally {
                surfaceHolder.unlockCanvasAndPost(c)
            }
        }
    }
}
