package com.wavetunes.ui

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.os.Build
import android.util.LruCache
import android.util.Size
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.wavetunes.data.Song
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private val cache = LruCache<Long, Bitmap>(64)

@Composable
fun rememberSongBitmap(song: Song?): State<Bitmap?> {
    val ctx = LocalContext.current
    return produceState<Bitmap?>(song?.let { cache.get(it.id) }, song?.id) {
        value = if (song == null) null
        else cache.get(song.id) ?: withContext(Dispatchers.IO) { loadArt(ctx, song) }?.also { cache.put(song.id, it) }
    }
}

/** Cover art read from the audio file itself (works on Android 10+ where old album-art URIs don't). */
@Composable
fun SongArt(song: Song, size: Dp, modifier: Modifier = Modifier, corner: Dp = 12.dp) {
    val cs = MaterialTheme.colorScheme
    val bmp by rememberSongBitmap(song)
    Box(
        modifier.size(size).clip(RoundedCornerShape(corner)).background(cs.surfaceVariant),
        contentAlignment = Alignment.Center,
    ) {
        val b = bmp
        if (b != null) Image(b.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        else Icon(Icons.Rounded.MusicNote, null, tint = cs.onSurfaceVariant)
    }
}

private fun loadArt(ctx: android.content.Context, song: Song): Bitmap? {
    if (Build.VERSION.SDK_INT >= 29) {
        runCatching { return ctx.contentResolver.loadThumbnail(song.uri, Size(300, 300), null) }
    }
    return runCatching {
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(ctx, song.uri)
            r.embeddedPicture?.let { BitmapFactory.decodeByteArray(it, 0, it.size) }
        } finally { r.release() }
    }.getOrNull()
}
