package com.wavetunes.ui

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.os.Build
import android.util.LruCache
import android.util.Size
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material3.Icon
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.wavetunes.data.ArtVersion
import com.wavetunes.data.CoverFetcher
import com.wavetunes.data.CoverStore
import com.wavetunes.data.Song
import com.wavetunes.data.generatedColor
import com.wavetunes.data.shiftHue
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private val cache = LruCache<Long, Bitmap>(64)

/** Bumped whenever a cover is changed so every screen reloads it. */
private object CoverVersion { var v by mutableIntStateOf(0) }

fun bumpCovers(id: Long) { cache.remove(id); CoverVersion.v++; ArtVersion.v++ }

fun resetCoverCache() { cache.evictAll(); CoverVersion.v++; ArtVersion.v++ }

suspend fun songBitmap(ctx: Context, song: Song): Bitmap? =
    cache.get(song.id) ?: loadArt(ctx, song)?.also { cache.put(song.id, it) }

@Composable
fun rememberSongBitmap(song: Song?): State<Bitmap?> {
    val ctx = LocalContext.current
    val version = CoverVersion.v
    return produceState<Bitmap?>(song?.let { cache.get(it.id) }, song?.id, version) {
        value = if (song == null) null else songBitmap(ctx, song)
    }
}

/** User's pick, else the file's cover, else found online automatically, else a generated gradient. */
@Composable
fun SongArt(song: Song, size: Dp, modifier: Modifier = Modifier, corner: Dp = 12.dp) {
    val bmp by rememberSongBitmap(song)
    Box(modifier.size(size).clip(RoundedCornerShape(corner)), contentAlignment = Alignment.Center) {
        val b = bmp
        if (b != null) Image(b.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        else GeneratedCover(song, Modifier.fillMaxSize())
    }
}

@Composable
fun GeneratedCover(song: Song, modifier: Modifier = Modifier) {
    val base = generatedColor(song)
    Box(modifier.background(Brush.linearGradient(listOf(base, shiftHue(base, 50f).copy(alpha = 1f)))), Alignment.Center) {
        Icon(Icons.Rounded.MusicNote, null, tint = Color.White.copy(alpha = 0.85f))
    }
}

private suspend fun loadArt(ctx: Context, song: Song): Bitmap? {
    if (withContext(Dispatchers.IO) { CoverStore.isGenerated(ctx, song) }) return null
    withContext(Dispatchers.IO) { CoverStore.chosen(ctx, song) }?.let { return it }
    withContext(Dispatchers.IO) { embeddedArt(ctx, song) }?.let { return it }
    return CoverFetcher.get(ctx, song)
}

/** The cover stored inside the audio file itself, if any. */
internal fun embeddedArt(ctx: Context, song: Song): Bitmap? {
    if (Build.VERSION.SDK_INT >= 29) {
        runCatching { return ctx.contentResolver.loadThumbnail(song.uri, Size(300, 300), null) }
    }
    return runCatching {
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(ctx, song.uri)
            r.embeddedPicture?.let { BitmapFactory.decodeByteArray(it, 0, it.size) }
        } finally { r.release() }
    }.getOrNull()
}
