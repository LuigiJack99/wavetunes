package com.wavetunes.ui

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.os.Build
import android.util.LruCache
import android.util.Size
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.wavetunes.data.CoverFetcher
import com.wavetunes.data.Song
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.abs

private val cache = LruCache<Long, Bitmap>(64)

@Composable
fun rememberSongBitmap(song: Song?): State<Bitmap?> {
    val ctx = LocalContext.current
    return produceState<Bitmap?>(song?.let { cache.get(it.id) }, song?.id) {
        value = if (song == null) null
        else cache.get(song.id) ?: loadArt(ctx, song)?.also { cache.put(song.id, it) }
    }
}

/** Cover from the file, else found online automatically, else a generated gradient. */
@Composable
fun SongArt(song: Song, size: Dp, modifier: Modifier = Modifier, corner: Dp = 12.dp) {
    val bmp by rememberSongBitmap(song)
    Box(
        modifier.size(size).clip(RoundedCornerShape(corner)),
        contentAlignment = Alignment.Center,
    ) {
        val b = bmp
        if (b != null) Image(b.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        else Box(Modifier.fillMaxSize().background(Brush.linearGradient(gradientFor(song))), Alignment.Center) {
            Icon(Icons.Rounded.MusicNote, null, tint = Color.White.copy(alpha = 0.85f))
        }
    }
}

private fun gradientFor(song: Song): List<Color> {
    val h = (abs(song.title.hashCode()) % 360).toFloat()
    return listOf(Color.hsv(h, 0.55f, 0.65f), Color.hsv((h + 50f) % 360f, 0.65f, 0.4f))
}

private suspend fun loadArt(ctx: Context, song: Song): Bitmap? {
    withContext(Dispatchers.IO) { embeddedArt(ctx, song) }?.let { return it }
    return CoverFetcher.get(ctx, song)
}

private fun embeddedArt(ctx: Context, song: Song): Bitmap? {
    if (Build.VERSION.SDK_INT >= 29) {
        runCatching { return ctx.contentResolver.loadThumbnail(song.uri, Size(300, 300), null) }
    }
    return runCatching {
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(ctx, song.uri)
            r.embeddedPicture?.let { BitmapFactory.decodeByteArray(it, 0, it.size) }
        } finally { r.release() }
    }.getOrNull()
}
