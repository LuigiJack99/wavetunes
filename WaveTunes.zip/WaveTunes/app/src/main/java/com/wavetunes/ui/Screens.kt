package com.wavetunes.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.wavetunes.AppViewModel
import com.wavetunes.data.Screen
import com.wavetunes.data.Song

@Composable
internal fun Header(title: String, onBack: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
        IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Back") }
        Text(title, style = MaterialTheme.typography.titleLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun SongList(vm: AppViewModel, list: List<Song>, empty: String) {
    val now by vm.nowPlaying.collectAsState()
    if (list.isEmpty()) {
        Text(empty, Modifier.padding(24.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
        return
    }
    LazyColumn {
        itemsIndexed(list, key = { _, s -> s.id }) { i, s ->
            ListItem(
                modifier = Modifier.clickable { vm.play(list, i) },
                colors = ListItemDefaults.colors(containerColor = androidx.compose.ui.graphics.Color.Transparent),
                headlineContent = {
                    Text(s.title, maxLines = 1, overflow = TextOverflow.Ellipsis,
                        color = if (now?.id == s.id) MaterialTheme.colorScheme.primary else androidx.compose.ui.graphics.Color.Unspecified)
                },
                supportingContent = { Text(s.artist, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                leadingContent = {
                    SongArt(s, 48.dp)
                },
            )
        }
    }
}

@Composable
fun LibraryScreen(vm: AppViewModel, pad: PaddingValues) {
    val songs by vm.songs.collectAsState()
    Column(Modifier.padding(pad)) {
        Header("All songs") { vm.screen.value = Screen.Home }
        SongList(vm, songs, "No music found. Copy audio files to this phone and allow music access.")
    }
}

@Composable
fun PlaylistScreen(vm: AppViewModel, id: String, pad: PaddingValues) {
    val songs by vm.songs.collectAsState()
    val playlists by vm.playlists.collectAsState()
    val pl = playlists.firstOrNull { it.id == id }
    val list = remember(songs, pl) { pl?.songIds?.mapNotNull { sid -> songs.firstOrNull { it.id == sid } }.orEmpty() }
    Column(Modifier.padding(pad)) {
        Header(pl?.name ?: "Playlist") { vm.screen.value = Screen.Home }
        SongList(vm, list, "None of this playlist's songs are on the phone right now.")
    }
}
