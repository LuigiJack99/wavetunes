package com.wavetunes.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.wavetunes.AppViewModel
import com.wavetunes.data.Screen
import com.wavetunes.data.Song

@Composable
internal fun Header(title: String, actions: @Composable RowScope.() -> Unit = {}, onBack: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Back") }
        Text(title, Modifier.weight(1f), style = MaterialTheme.typography.titleLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
        actions()
    }
}

@Composable
private fun SongList(vm: AppViewModel, list: List<Song>, empty: String, playlistId: String? = null) {
    val now by vm.nowPlaying.collectAsState()
    var addFor by remember { mutableStateOf<Song?>(null) }
    if (list.isEmpty()) {
        Text(empty, Modifier.padding(24.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
        return
    }
    LazyColumn {
        itemsIndexed(list, key = { _, s -> s.id }) { i, s ->
            var menu by remember { mutableStateOf(false) }
            ListItem(
                modifier = Modifier.clickable { vm.play(list, i) },
                colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                headlineContent = {
                    Text(
                        s.title, maxLines = 1, overflow = TextOverflow.Ellipsis,
                        color = if (now?.id == s.id) MaterialTheme.colorScheme.primary else Color.Unspecified,
                    )
                },
                supportingContent = { Text(s.artist, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                leadingContent = { SongArt(s, 48.dp) },
                trailingContent = {
                    Box {
                        IconButton(onClick = { menu = true }) { Icon(Icons.Rounded.MoreVert, "More") }
                        DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                            DropdownMenuItem(text = { Text("Add to playlist") }, onClick = { menu = false; addFor = s })
                            if (playlistId != null) DropdownMenuItem(
                                text = { Text("Remove from playlist") },
                                onClick = { menu = false; vm.removeFromPlaylist(playlistId, s.id) },
                            )
                        }
                    }
                },
            )
        }
    }
    addFor?.let { AddToPlaylistDialog(vm, it) { addFor = null } }
}

@Composable
fun LibraryScreen(vm: AppViewModel, pad: PaddingValues) {
    val songs by vm.songs.collectAsState()
    Column(Modifier.padding(pad)) {
        Header("All songs") { vm.screen.value = Screen.Home }
        SongList(vm, songs, "No music found. Copy audio files to this phone and allow music access.")
    }
}

@Composable
fun PlaylistScreen(vm: AppViewModel, id: String, pad: PaddingValues) {
    val songs by vm.songs.collectAsState()
    val playlists by vm.playlists.collectAsState()
    val pl = playlists.firstOrNull { it.id == id }
    val list = remember(songs, pl) { pl?.songIds?.mapNotNull { sid -> songs.firstOrNull { it.id == sid } }.orEmpty() }
    var adding by remember { mutableStateOf(false) }
    var deleting by remember { mutableStateOf(false) }

    Column(Modifier.padding(pad)) {
        Header(pl?.name ?: "Playlist", actions = {
            IconButton(onClick = { vm.play(list, 0) }, enabled = list.isNotEmpty()) { Icon(Icons.Rounded.PlayArrow, "Play all") }
            IconButton(onClick = { adding = true }) { Icon(Icons.Rounded.Add, "Add songs") }
            IconButton(onClick = { deleting = true }) { Icon(Icons.Rounded.Delete, "Delete playlist") }
        }) { vm.screen.value = Screen.Home }
        SongList(vm, list, "No songs yet. Tap + above, or use the ⋮ menu on any song.", id)
    }

    if (adding && pl != null) AddSongsDialog(
        songs = songs, existing = pl.songIds.toSet(),
        onAdd = { vm.addManyToPlaylist(id, it) }, onDismiss = { adding = false },
    )
    if (deleting) AlertDialog(
        onDismissRequest = { deleting = false },
        title = { Text("Delete playlist?") },
        text = { Text("The songs stay on your phone. Only the playlist is removed.") },
        confirmButton = {
            TextButton(onClick = { deleting = false; vm.screen.value = Screen.Home; vm.deletePlaylist(id) }) { Text("Delete") }
        },
        dismissButton = { TextButton(onClick = { deleting = false }) { Text("Cancel") } },
    )
}

@Composable
internal fun NewPlaylistDialog(onDismiss: () -> Unit, onCreate: (String) -> Unit) {
    var name by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("New playlist") },
        text = { OutlinedTextField(name, { name = it }, label = { Text("Name") }, singleLine = true) },
        confirmButton = { TextButton(onClick = { onCreate(name) }, enabled = name.isNotBlank()) { Text("Create") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

@Composable
private fun AddToPlaylistDialog(vm: AppViewModel, song: Song, onDismiss: () -> Unit) {
    val playlists by vm.playlists.collectAsState()
    var creating by remember { mutableStateOf(false) }
    if (creating) {
        NewPlaylistDialog(onDismiss = onDismiss) { name -> vm.createPlaylist(name, song.id); onDismiss() }
        return
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add to playlist") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                playlists.forEach { p ->
                    TextButton(onClick = { vm.addToPlaylist(p.id, song.id); onDismiss() }, modifier = Modifier.fillMaxWidth()) {
                        Text(p.name, Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
                TextButton(onClick = { creating = true }, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Rounded.Add, null)
                    Spacer(Modifier.width(8.dp))
                    Text("New playlist", Modifier.weight(1f))
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

@Composable
private fun AddSongsDialog(songs: List<Song>, existing: Set<Long>, onAdd: (List<Long>) -> Unit, onDismiss: () -> Unit) {
    val picked = remember { mutableStateListOf<Long>() }
    val choices = remember(songs, existing) { songs.filter { it.id !in existing } }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add songs") },
        text = {
            if (choices.isEmpty()) Text("Every song on your phone is already in this playlist.")
            else LazyColumn(Modifier.heightIn(max = 420.dp)) {
                items(choices, key = { it.id }) { s ->
                    Row(
                        Modifier.fillMaxWidth()
                            .clickable { if (s.id in picked) picked.remove(s.id) else picked.add(s.id) }
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Checkbox(checked = s.id in picked, onCheckedChange = null)
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text(s.title, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(s.artist, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { onAdd(picked.toList()); onDismiss() }, enabled = picked.isNotEmpty()) { Text("Add ${picked.size}") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}
