package com.wavetunes.ui

import android.graphics.Bitmap
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.BlurredEdgeTreatment
import androidx.compose.ui.draw.blur
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.wavetunes.data.Song
import kotlin.math.PI
import kotlin.math.sin

private const val TWO_PI = (2 * PI).toFloat()

/**
 * Bottom player. Its background is the blurred cover of the current song, the wave takes the
 * cover's color, and the wave doubles as the seek bar (tap or drag). Controls sit in the middle.
 * The wave is a squiggly line that moves and swells with the live audio level; paused = flat.
 */
@Composable
fun EqualizerBar(
    song: Song?,
    isPlaying: Boolean,
    progress: Float,
    bars: FloatArray,
    onSeek: (Float) -> Unit,
    onPrev: () -> Unit,
    onPlayPause: () -> Unit,
    onNext: () -> Unit,
    onLyrics: () -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    val art by rememberSongBitmap(song)
    val accentTarget = remember(art, cs.primary) { art?.let(::accentFrom) ?: cs.primary }
    val accent by animateColorAsState(accentTarget, label = "accent")
    val hasArt = art != null
    val textColor = if (hasArt) Color.White else cs.onSurface

    var drag by remember { mutableStateOf<Float?>(null) }
    val seek by rememberUpdatedState(onSeek)
    val shown = drag ?: progress

    val phase by rememberInfiniteTransition(label = "phase").animateFloat(
        0f, TWO_PI, infiniteRepeatable(tween(1400, easing = LinearEasing)), label = "phase"
    )
    val level = if (bars.isEmpty()) 0f else (bars.average().toFloat() * 2.2f).coerceIn(0f, 1f)
    val amp by animateFloatAsState(if (isPlaying) 0.25f + 0.75f * level else 0f, tween(150), label = "amp")

    Surface(
        color = cs.surfaceContainer,
        shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
        tonalElevation = 3.dp,
    ) {
        Box {
            art?.let { b ->
                Image(
                    b.asImageBitmap(), null,
                    Modifier.matchParentSize().blur(28.dp, BlurredEdgeTreatment.Unbounded),
                    contentScale = ContentScale.Crop,
                )
                Box(Modifier.matchParentSize().background(Color.Black.copy(alpha = 0.55f)))
            }
            Column(Modifier.navigationBarsPadding().height(176.dp)) {
                Row(
                    Modifier.fillMaxWidth().padding(start = 20.dp, end = 8.dp, top = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(
                            song?.title ?: "Nothing playing",
                            style = MaterialTheme.typography.titleMedium, color = textColor,
                            maxLines = 1, overflow = TextOverflow.Ellipsis,
                        )
                        Text(
                            song?.artist ?: "Pick a song to start",
                            style = MaterialTheme.typography.bodySmall, color = textColor.copy(alpha = 0.7f),
                            maxLines = 1, overflow = TextOverflow.Ellipsis,
                        )
                    }
                    IconButton(onClick = onLyrics, enabled = song != null) {
                        Icon(Icons.Rounded.Lyrics, "Lyrics", tint = textColor)
                    }
                }
                Box(Modifier.weight(1f).fillMaxWidth()) {
                    Canvas(
                        Modifier.fillMaxSize()
                            .pointerInput(Unit) {
                                detectTapGestures { o -> seek((o.x / size.width).coerceIn(0f, 1f)) }
                            }
                            .pointerInput(Unit) {
                                detectHorizontalDragGestures(
                                    onDragStart = { o -> drag = (o.x / size.width).coerceIn(0f, 1f) },
                                    onDragEnd = { drag?.let(seek); drag = null },
                                    onDragCancel = { drag = null },
                                ) { change, _ -> drag = (change.position.x / size.width).coerceIn(0f, 1f) }
                            }
                    ) {
                        val w = size.width; val midY = size.height / 2f
                        val stroke = 6.dp.toPx()
                        val a = amp * 18.dp.toPx()
                        val lambda = 44.dp.toPx()
                        val step = 4.dp.toPx()
                        val px = (w * shown).coerceIn(0f, w)
                        fun waveY(x: Float) = midY + a * sin(TWO_PI * x / lambda - phase)

                        // played part: moving wave
                        val wave = Path().apply {
                            moveTo(0f, waveY(0f))
                            var x = step
                            while (x < px) { lineTo(x, waveY(x)); x += step }
                            lineTo(px, waveY(px))
                        }
                        drawPath(wave, accent, style = Stroke(stroke, cap = StrokeCap.Round, join = StrokeJoin.Round))
                        // remaining part: flat line
                        drawLine(accent.copy(alpha = 0.35f), Offset(px, midY), Offset(w, midY), stroke * 0.7f, StrokeCap.Round)
                        // handle
                        val ty = waveY(px)
                        drawRoundRect(
                            Color.White,
                            topLeft = Offset(px - 3.dp.toPx(), ty - 14.dp.toPx()),
                            size = Size(6.dp.toPx(), 28.dp.toPx()),
                            cornerRadius = CornerRadius(3.dp.toPx()),
                        )
                    }
                    Surface(
                        modifier = Modifier.align(Alignment.Center),
                        shape = CircleShape,
                        color = if (hasArt) Color.Black.copy(alpha = 0.45f) else cs.surface.copy(alpha = 0.82f),
                        contentColor = textColor,
                    ) {
                        Row(
                            Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            IconButton(onClick = onPrev) { Icon(Icons.Rounded.SkipPrevious, "Previous") }
                            FilledIconButton(
                                onClick = onPlayPause, modifier = Modifier.size(56.dp),
                                colors = IconButtonDefaults.filledIconButtonColors(
                                    containerColor = accent,
                                    contentColor = if (hasArt) Color.Black else cs.onPrimary,
                                ),
                            ) {
                                Icon(
                                    if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                                    if (isPlaying) "Pause" else "Play", Modifier.size(32.dp),
                                )
                            }
                            IconButton(onClick = onNext) { Icon(Icons.Rounded.SkipNext, "Next") }
                        }
                    }
                }
            }
        }
    }
}

/** Average color of the cover, pushed to a bright, saturated shade so it reads on the dark overlay. */
private fun accentFrom(b: Bitmap): Color {
    val px = Bitmap.createScaledBitmap(b, 1, 1, true).getPixel(0, 0)
    val hsv = FloatArray(3)
    android.graphics.Color.colorToHSV(px, hsv)
    hsv[1] = hsv[1].coerceAtLeast(0.45f)
    hsv[2] = hsv[2].coerceAtLeast(0.9f)
    return Color(android.graphics.Color.HSVToColor(hsv))
}
