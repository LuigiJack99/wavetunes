package com.wavetunes.ui

import android.graphics.Bitmap
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.BlurredEdgeTreatment
import androidx.compose.ui.draw.blur
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.wavetunes.data.Song

/**
 * Bottom player. The live audio visualizer fills the bottom of the screen and the controls sit
 * over it. Background = blurred cover of the current song; visualizer color comes from the cover.
 * The thin line at the top is the seek bar (tap or drag).
 */
@Composable
fun EqualizerBar(
    song: Song?,
    isPlaying: Boolean,
    progress: Float,
    bars: FloatArray,
    onSeek: (Float) -> Unit,
    onPrev: () -> Unit,
    onPlayPause: () -> Unit,
    onNext: () -> Unit,
    onLyrics: () -> Unit,
    accentColor: Color,
    shuffleOn: Boolean,
    onShuffle: () -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    val art by rememberSongBitmap(song)
    val accent by animateColorAsState(accentColor, label = "accent")
    val hasArt = art != null
    val textColor = if (hasArt) Color.White else cs.onSurface

    var drag by remember { mutableStateOf<Float?>(null) }
    val seek by rememberUpdatedState(onSeek)
    val shown = drag ?: progress

    Surface(
        color = cs.surfaceContainer,
        shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
        tonalElevation = 3.dp,
    ) {
        Box {
            // 1. background: blurred cover (crossfades when the song changes)
            Crossfade(art, Modifier.matchParentSize(), label = "cover") { b ->
                if (b != null) Box(Modifier.fillMaxSize()) {
                    Image(
                        b.asImageBitmap(), null,
                        Modifier.fillMaxSize().blur(28.dp, BlurredEdgeTreatment.Unbounded),
                        contentScale = ContentScale.Crop,
                    )
                    Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.55f)))
                }
            }

            // 2. the visualizer, anchored to the very bottom edge of the screen
            Canvas(Modifier.matchParentSize()) {
                val n = bars.size
                if (n == 0) return@Canvas
                val gap = 4.dp.toPx()
                val bw = (size.width - gap * (n - 1)) / n
                val maxH = size.height * 0.92f
                val brush = Brush.verticalGradient(listOf(accent.copy(alpha = 0.95f), accent.copy(alpha = 0.25f)))
                for (i in 0 until n) {
                    val bh = maxOf(bars[i], 0.04f) * maxH
                    drawRoundRect(
                        brush,
                        topLeft = Offset(i * (bw + gap), size.height - bh),
                        size = Size(bw, bh),
                        cornerRadius = CornerRadius(bw / 2),
                    )
                }
            }

            // 3. controls over the visualizer
            Column(Modifier.navigationBarsPadding().height(196.dp)) {
                // seek line
                Box(
                    Modifier.fillMaxWidth().height(28.dp).padding(horizontal = 20.dp)
                        .pointerInput(Unit) {
                            detectTapGestures { o -> seek((o.x / size.width).coerceIn(0f, 1f)) }
                        }
                        .pointerInput(Unit) {
                            detectHorizontalDragGestures(
                                onDragStart = { o -> drag = (o.x / size.width).coerceIn(0f, 1f) },
                                onDragEnd = { drag?.let(seek); drag = null },
                                onDragCancel = { drag = null },
                            ) { change, _ -> drag = (change.position.x / size.width).coerceIn(0f, 1f) }
                        }
                ) {
                    Canvas(Modifier.fillMaxSize()) {
                        val y = size.height / 2f
                        val px = size.width * shown.coerceIn(0f, 1f)
                        drawLine(Color.White.copy(alpha = 0.25f), Offset(0f, y), Offset(size.width, y), 4.dp.toPx(), StrokeCap.Round)
                        drawLine(accent, Offset(0f, y), Offset(px, y), 4.dp.toPx(), StrokeCap.Round)
                        drawCircle(Color.White, 6.dp.toPx(), Offset(px, y))
                    }
                }
                // title + lyrics button
                Row(
                    Modifier.fillMaxWidth().padding(start = 20.dp, end = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(
                            song?.title ?: "Nothing playing",
                            style = MaterialTheme.typography.titleMedium, color = textColor,
                            maxLines = 1, overflow = TextOverflow.Ellipsis,
                        )
                        Text(
                            song?.artist ?: "Pick a song to start",
                            style = MaterialTheme.typography.bodySmall, color = textColor.copy(alpha = 0.7f),
                            maxLines = 1, overflow = TextOverflow.Ellipsis,
                        )
                    }
                    IconButton(onClick = onLyrics, enabled = song != null) {
                        Icon(Icons.Rounded.Lyrics, "Lyrics", tint = textColor)
                    }
                }
                // prev / play / next
                Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                    Surface(
                        shape = CircleShape,
                        color = if (hasArt) Color.Black.copy(alpha = 0.45f) else cs.surface.copy(alpha = 0.82f),
                        contentColor = textColor,
                    ) {
                        Row(
                            Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            IconButton(onClick = onShuffle) {
                                Icon(Icons.Rounded.Shuffle, "Shuffle", tint = if (shuffleOn) accent else textColor.copy(alpha = 0.6f))
                            }
                            IconButton(onClick = onPrev) { Icon(Icons.Rounded.SkipPrevious, "Previous") }
                            FilledIconButton(
                                onClick = onPlayPause, modifier = Modifier.size(56.dp),
                                colors = IconButtonDefaults.filledIconButtonColors(
                                    containerColor = accent,
                                    contentColor = if (hasArt) Color.Black else cs.onPrimary,
                                ),
                            ) {
                                AnimatedContent(
                                    isPlaying, label = "playpause",
                                    transitionSpec = { (fadeIn() + scaleIn()) togetherWith (fadeOut() + scaleOut()) },
                                ) { playing ->
                                    Icon(
                                        if (playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                                        if (playing) "Pause" else "Play", Modifier.size(32.dp),
                                    )
                                }
                            }
                            IconButton(onClick = onNext) { Icon(Icons.Rounded.SkipNext, "Next") }
                        }
                    }
                }
            }
        }
    }
}
