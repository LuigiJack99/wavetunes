package com.wavetunes.ui

import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.wavetunes.data.Song

/**
 * Bottom wave equalizer. The wave doubles as the seek bar (tap or drag),
 * and the song controls sit in the middle of it.
 */
@Composable
fun EqualizerBar(
    song: Song?,
    isPlaying: Boolean,
    progress: Float,
    bars: FloatArray,
    onSeek: (Float) -> Unit,
    onPrev: () -> Unit,
    onPlayPause: () -> Unit,
    onNext: () -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    var drag by remember { mutableStateOf<Float?>(null) }
    val seek by rememberUpdatedState(onSeek)
    val shown = drag ?: progress

    Surface(
        color = cs.surfaceContainer,
        shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
        tonalElevation = 3.dp,
    ) {
        Column(Modifier.navigationBarsPadding().height(176.dp)) {
            Column(Modifier.padding(start = 20.dp, end = 20.dp, top = 14.dp)) {
                Text(
                    song?.title ?: "Nothing playing",
                    style = MaterialTheme.typography.titleMedium,
                    maxLines = 1, overflow = TextOverflow.Ellipsis,
                )
                Text(
                    song?.artist ?: "Pick a song to start",
                    style = MaterialTheme.typography.bodySmall,
                    color = cs.onSurfaceVariant,
                    maxLines = 1, overflow = TextOverflow.Ellipsis,
                )
            }
            Box(Modifier.weight(1f).fillMaxWidth()) {
                androidx.compose.foundation.Canvas(
                    Modifier.fillMaxSize()
                        .pointerInput(Unit) {
                            detectTapGestures { o -> seek((o.x / size.width).coerceIn(0f, 1f)) }
                        }
                        .pointerInput(Unit) {
                            detectHorizontalDragGestures(
                                onDragStart = { o -> drag = (o.x / size.width).coerceIn(0f, 1f) },
                                onDragEnd = { drag?.let(seek); drag = null },
                                onDragCancel = { drag = null },
                            ) { change, _ -> drag = (change.position.x / size.width).coerceIn(0f, 1f) }
                        }
                ) {
                    val w = size.width; val h = size.height; val mid = h / 2f; val n = bars.size
                    if (n < 2) return@Canvas
                    val amp = mid * 0.92f
                    val top = List(n) { i -> Offset(w * i / (n - 1), mid - maxOf(bars[i], 0.05f) * amp) }
                    val bottom = List(n) { i -> Offset(w * i / (n - 1), mid + maxOf(bars[i], 0.05f) * amp * 0.6f) }
                    val wave = Path().apply {
                        moveTo(0f, mid)
                        smoothTo(top)
                        smoothTo(bottom.asReversed())
                        close()
                    }
                    drawPath(wave, cs.onSurfaceVariant.copy(alpha = 0.28f))
                    clipRect(right = w * shown) {
                        drawPath(wave, Brush.horizontalGradient(listOf(cs.primary, cs.tertiary)))
                    }
                    drawLine(cs.primary, Offset(w * shown, 0f), Offset(w * shown, h), strokeWidth = 3.dp.toPx())
                }
                Surface(
                    modifier = Modifier.align(Alignment.Center),
                    shape = CircleShape,
                    color = cs.surface.copy(alpha = 0.82f),
                ) {
                    Row(
                        Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        IconButton(onClick = onPrev) { Icon(Icons.Rounded.SkipPrevious, "Previous") }
                        FilledIconButton(onClick = onPlayPause, modifier = Modifier.size(56.dp)) {
                            Icon(
                                if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                                if (isPlaying) "Pause" else "Play",
                                Modifier.size(32.dp),
                            )
                        }
                        IconButton(onClick = onNext) { Icon(Icons.Rounded.SkipNext, "Next") }
                    }
                }
            }
        }
    }
}

private fun Path.smoothTo(pts: List<Offset>) {
    lineTo(pts[0].x, pts[0].y)
    for (i in 1 until pts.size) {
        val a = pts[i - 1]; val b = pts[i]
        quadraticBezierTo(a.x, a.y, (a.x + b.x) / 2, (a.y + b.y) / 2)
    }
    lineTo(pts.last().x, pts.last().y)
}
