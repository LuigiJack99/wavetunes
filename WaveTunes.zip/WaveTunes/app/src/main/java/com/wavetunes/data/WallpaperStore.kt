package com.wavetunes.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.provider.OpenableColumns
import java.io.File

/** The user's own wallpaper images, one per album color family. */
object WallpaperStore {
    fun file(ctx: Context, fam: HueFamily) =
        File(File(ctx.filesDir, "wallpapers").apply { mkdirs() }, "${fam.name}.jpg")

    /** Copies the picked image into app storage. Returns its file name, or null if it can't be read. */
    fun save(ctx: Context, fam: HueFamily, uri: Uri): String? {
        val bmp = decodeUri(ctx, uri, 2560) ?: return null
        file(ctx, fam).outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 92, it) }
        val name = runCatching {
            ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
                if (it.moveToFirst()) it.getString(0) else null
            }
        }.getOrNull()
        return name ?: "Custom image"
    }

    fun decodeFile(path: String, maxSide: Int): Bitmap? {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(path, o)
        var sample = 1
        while (o.outWidth / (sample * 2) >= maxSide || o.outHeight / (sample * 2) >= maxSide) sample *= 2
        return BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = sample })
    }

    private fun decodeUri(ctx: Context, uri: Uri, max: Int): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (bounds.outWidth / (sample * 2) >= max || bounds.outHeight / (sample * 2) >= max) sample *= 2
        return ctx.contentResolver.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample })
        }
    }
}
