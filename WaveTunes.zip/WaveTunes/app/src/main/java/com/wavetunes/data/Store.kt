package com.wavetunes.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Tiny JSON-in-SharedPreferences store for playlists, home layout and Spotify token. */
class Store(ctx: Context) {
    private val sp = ctx.getSharedPreferences("wavetunes", Context.MODE_PRIVATE)

    fun loadPlaylists(): List<LocalPlaylist> = runCatching {
        val arr = JSONArray(sp.getString("playlists", "[]"))
        List(arr.length()) { i ->
            val o = arr.getJSONObject(i)
            val ids = o.getJSONArray("songs")
            LocalPlaylist(o.getString("id"), o.getString("name"), List(ids.length()) { ids.getLong(it) })
        }
    }.getOrDefault(emptyList())

    fun savePlaylists(list: List<LocalPlaylist>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().put("id", it.id).put("name", it.name).put("songs", JSONArray(it.songIds)))
        }
        sp.edit().putString("playlists", arr.toString()).apply()
    }

    fun loadLayout(): List<HomeBlock> {
        val saved = runCatching {
            val arr = JSONArray(sp.getString("layout", "[]"))
            List(arr.length()) { i ->
                val o = arr.getJSONObject(i)
                HomeBlock(BlockType.valueOf(o.getString("type")), o.getBoolean("visible"), o.getBoolean("full"))
            }
        }.getOrDefault(emptyList())
        // Append any block types that aren't saved yet (first launch or app update)
        val missing = BlockType.entries.filter { t -> saved.none { it.type == t } }.map { HomeBlock(it) }
        return saved + missing
    }

    fun saveLayout(list: List<HomeBlock>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().put("type", it.type.name).put("visible", it.visible).put("full", it.full))
        }
        sp.edit().putString("layout", arr.toString()).apply()
    }

    var verifier: String?
        get() = sp.getString("verifier", null)
        set(v) = sp.edit().putString("verifier", v).apply()

    var token: String?
        get() = sp.getString("token", null)
        private set(v) = sp.edit().putString("token", v).apply()

    private var expiry: Long
        get() = sp.getLong("expiry", 0L)
        set(v) = sp.edit().putLong("expiry", v).apply()

    fun saveToken(token: String, expiresInSec: Long) {
        this.token = token
        expiry = System.currentTimeMillis() + expiresInSec * 1000
    }

    fun tokenValid() = token != null && System.currentTimeMillis() < expiry - 30_000
}
