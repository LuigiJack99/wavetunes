package com.wavetunes.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Tiny JSON-in-SharedPreferences store for playlists, home layout and Spotify token. */
class Store(private val ctx: Context) {
    private val sp = ctx.getSharedPreferences("wavetunes", Context.MODE_PRIVATE)

    fun loadPlaylists(): List<LocalPlaylist> = runCatching {
        val arr = JSONArray(sp.getString("playlists", "[]"))
        List(arr.length()) { i ->
            val o = arr.getJSONObject(i)
            val ids = o.getJSONArray("songs")
            LocalPlaylist(o.getString("id"), o.getString("name"), List(ids.length()) { ids.getLong(it) })
        }
    }.getOrDefault(emptyList())

    fun savePlaylists(list: List<LocalPlaylist>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().put("id", it.id).put("name", it.name).put("songs", JSONArray(it.songIds)))
        }
        sp.edit().putString("playlists", arr.toString()).apply()
    }

    fun loadLayout(): List<HomeBlock> {
        val saved = runCatching {
            val arr = JSONArray(sp.getString("layout", "[]"))
            List(arr.length()) { i ->
                val o = arr.getJSONObject(i)
                HomeBlock(BlockType.valueOf(o.getString("type")), o.getBoolean("visible"), o.getBoolean("full"))
            }
        }.getOrDefault(emptyList())
        // Append any block types that aren't saved yet (first launch or app update)
        val missing = BlockType.entries.filter { t -> saved.none { it.type == t } }.map { HomeBlock(it) }
        return saved + missing
    }

    fun saveLayout(list: List<HomeBlock>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().put("type", it.type.name).put("visible", it.visible).put("full", it.full))
        }
        sp.edit().putString("layout", arr.toString()).apply()
    }

    var verifier: String?
        get() = sp.getString("verifier", null)
        set(v) = sp.edit().putString("verifier", v).apply()

    var token: String?
        get() = sp.getString("token", null)
        private set(v) = sp.edit().putString("token", v).apply()

    private var expiry: Long
        get() = sp.getLong("expiry", 0L)
        set(v) = sp.edit().putLong("expiry", v).apply()

    fun saveToken(token: String, expiresInSec: Long) {
        this.token = token
        expiry = System.currentTimeMillis() + expiresInSec * 1000
    }

    fun tokenValid() = token != null && System.currentTimeMillis() < expiry - 30_000

    /** v1 cached whatever the first online match was (often a compilation). Drop those once. */
    fun migrateCovers() {
        if (sp.getInt("cover_migration", 0) >= 2) return
        java.io.File(ctx.filesDir, "covers").listFiles()?.forEach {
            if (it.name.endsWith(".jpg") || it.name.endsWith(".none")) it.delete()
        }
        sp.edit().putInt("cover_migration", 2).apply()
    }

    // ---- settings ----
    fun loadSettings(): AppSettings = runCatching {
        val o = JSONObject(sp.getString("settings", "{}") ?: "{}")
        val d = AppSettings()
        val hue = o.optJSONObject("hue")
        val wp = o.optJSONObject("wallpapers")
        val wallpapers = HueFamily.entries.mapNotNull { f ->
            if (wp != null && wp.has(f.name)) f to wp.getString(f.name) else null
        }.toMap()
        val overrides = HueFamily.entries.mapNotNull { f ->
            if (hue != null && hue.has(f.name)) f to hue.getInt(f.name) else null
        }.toMap()
        AppSettings(
            themeMode = enumOr(o.optString("themeMode"), d.themeMode),
            colorSource = enumOr(o.optString("colorSource"), d.colorSource),
            customColor = o.optInt("customColor", d.customColor),
            bgStyle = enumOr(o.optString("bgStyle"), d.bgStyle),
            bgAnimated = o.optBoolean("bgAnimated", d.bgAnimated),
            bgIntensity = o.optDouble("bgIntensity", d.bgIntensity.toDouble()).toFloat(),
            wpStyle = enumOr(o.optString("wpStyle"), d.wpStyle),
            barCount = o.optInt("barCount", d.barCount),
            hueOverrides = overrides,
            wallpapers = wallpapers,
            yearRules = if (o.has("yearRules")) o.getJSONObject("yearRules").let { j -> j.keys().asSequence().associateWith { k -> j.getInt(k) } } else d.yearRules,
        )
    }.getOrDefault(AppSettings())

    fun saveSettings(s: AppSettings) {
        val hue = JSONObject()
        s.hueOverrides.forEach { (f, c) -> hue.put(f.name, c) }
        val wp = JSONObject()
        s.wallpapers.forEach { (f, n) -> wp.put(f.name, n) }
        val o = JSONObject()
            .put("themeMode", s.themeMode.name).put("colorSource", s.colorSource.name)
            .put("customColor", s.customColor).put("bgStyle", s.bgStyle.name)
            .put("bgAnimated", s.bgAnimated).put("bgIntensity", s.bgIntensity.toDouble())
            .put("wpStyle", s.wpStyle.name).put("barCount", s.barCount).put("hue", hue)
            .put("wallpapers", wp)
            .put("yearRules", JSONObject().also { j -> s.yearRules.forEach { (a, y) -> j.put(a, y) } })
        sp.edit().putString("settings", o.toString()).apply()
    }

    /** The live wallpaper service reads these. */
    fun saveWallpaper(color: Int, s: AppSettings, image: String?) {
        ctx.getSharedPreferences(WALLPAPER_PREFS, Context.MODE_PRIVATE).edit()
            .putInt("color", color).putString("style", s.wpStyle.name).putString("image", image ?: "")
            .putBoolean("animated", s.bgAnimated).putFloat("intensity", s.bgIntensity).apply()
    }

    private inline fun <reified T : Enum<T>> enumOr(name: String, default: T): T =
        enumValues<T>().firstOrNull { it.name == name } ?: default
}

const val WALLPAPER_PREFS = "wavetunes_wallpaper"
