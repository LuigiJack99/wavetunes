package com.wavetunes.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.HttpUrl
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.abs

data class LyricLine(val timeMs: Long, val text: String)

/** [synced] = lines carry timestamps; otherwise timeMs is -1 and it's plain text. */
data class SongLyrics(val lines: List<LyricLine>, val synced: Boolean)

/** Fetches lyrics from LRCLIB (lrclib.net): free, no account or key. */
object LyricsApi {
    private val http = OkHttpClient()
    private val stamp = Regex("\\[(\\d+):(\\d+(?:\\.\\d+)?)]")

    suspend fun fetch(song: Song): SongLyrics? = withContext(Dispatchers.IO) {
        runCatching {
            val secs = song.durationMs / 1000
            val artist = song.artist.replace(" & ", ",").substringBefore(",").trim()
                .takeIf { it != "Unknown artist" }.orEmpty()

            val exact = HttpUrl.Builder().scheme("https").host("lrclib.net").addPathSegments("api/get")
                .addQueryParameter("track_name", song.title)
                .addQueryParameter("artist_name", artist)
                .addQueryParameter("album_name", song.album)
                .addQueryParameter("duration", secs.toString())
                .build()
            requestObject(exact)?.let { parse(it) }?.let { return@runCatching it }

            val search = HttpUrl.Builder().scheme("https").host("lrclib.net").addPathSegments("api/search")
                .addQueryParameter("q", "$artist ${song.title}".trim())
                .build()
            val arr = requestArray(search) ?: return@runCatching null
            val results = List(arr.length()) { arr.getJSONObject(it) }
            results.sortedBy { abs(it.optDouble("duration", 0.0) - secs) }
                .firstNotNullOfOrNull { parse(it) }
        }.getOrNull()
    }

    private fun call(url: HttpUrl): String? {
        val req = Request.Builder().url(url).header("User-Agent", "WaveTunes/1.0").build()
        http.newCall(req).execute().use { r -> return if (r.isSuccessful) r.body?.string() else null }
    }
    private fun requestObject(url: HttpUrl) = call(url)?.let { JSONObject(it) }
    private fun requestArray(url: HttpUrl) = call(url)?.let { JSONArray(it) }

    private fun str(o: JSONObject, key: String) = if (o.isNull(key)) "" else o.optString(key)

    private fun parse(o: JSONObject): SongLyrics? {
        val synced = str(o, "syncedLyrics")
        if (synced.isNotBlank()) {
            val lines = synced.lines().flatMap { line ->
                val text = line.replace(stamp, "").trim().ifEmpty { "♪" }
                stamp.findAll(line).map { m ->
                    LyricLine(m.groupValues[1].toLong() * 60_000 + (m.groupValues[2].toDouble() * 1000).toLong(), text)
                }.toList()
            }.sortedBy { it.timeMs }
            if (lines.isNotEmpty()) return SongLyrics(lines, true)
        }
        val plain = str(o, "plainLyrics")
        if (plain.isNotBlank()) return SongLyrics(plain.lines().map { LyricLine(-1, it) }, false)
        return null
    }
}
