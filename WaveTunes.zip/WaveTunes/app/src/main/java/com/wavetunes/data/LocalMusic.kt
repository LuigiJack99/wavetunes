package com.wavetunes.data

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.provider.MediaStore

object LocalMusic {
    private val artBase: Uri = Uri.parse("content://media/external/audio/albumart")

    /** All music on the device, newest first. */
    fun scan(ctx: Context): List<Song> {
        val out = mutableListOf<Song>()
        val proj = arrayOf(
            MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM, MediaStore.Audio.Media.DURATION, MediaStore.Audio.Media.ALBUM_ID,
        )
        val sel = "${MediaStore.Audio.Media.IS_MUSIC} != 0 AND ${MediaStore.Audio.Media.DURATION} > 30000"
        ctx.contentResolver.query(
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, proj, sel, null,
            "${MediaStore.Audio.Media.DATE_ADDED} DESC"
        )?.use { c ->
            while (c.moveToNext()) {
                val id = c.getLong(0)
                var title = c.getString(1) ?: "Unknown"
                var artist = c.getString(2)?.takeIf { it != "<unknown>" && it.isNotBlank() }
                // Untagged files: read "Artist - Title" from the file name
                if (artist == null && " - " in title) {
                    artist = title.substringBefore(" - ").trim()
                    title = title.substringAfter(" - ").trim()
                }
                out += Song(
                    id = id,
                    title = title,
                    artist = artist ?: "Unknown artist",
                    album = c.getString(3) ?: "",
                    durationMs = c.getLong(4),
                    uri = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id),
                    art = ContentUris.withAppendedId(artBase, c.getLong(5)),
                )
            }
        }
        return out
    }
}
