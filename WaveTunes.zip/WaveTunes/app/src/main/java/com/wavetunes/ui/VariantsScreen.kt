package com.wavetunes.ui

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.wavetunes.AppViewModel
import com.wavetunes.data.CoverFetcher
import com.wavetunes.data.CoverStore
import com.wavetunes.data.Screen
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Settings > Image variants: every song; tap one to see and change its cover. */
@Composable
fun VariantsScreen(vm: AppViewModel, pad: PaddingValues) {
    val songs by vm.songs.collectAsState()
    Column(Modifier.padding(pad)) {
        Header("Image variants") { vm.back() }
        Text(
            if (songs.isEmpty()) "No songs found on this phone." else "Tap a song to see its cover variants and change the cover.",
            Modifier.padding(horizontal = 20.dp, vertical = 8.dp),
            style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        LazyColumn {
            itemsIndexed(songs, key = { _, s -> s.id }) { _, s ->
                ListItem(
                    modifier = Modifier.clickable { vm.screen.value = Screen.VariantPicker(s.id) },
                    colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                    headlineContent = { Text(s.title, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                    supportingContent = { Text(s.artist, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                    leadingContent = { SongArt(s, 48.dp) },
                )
            }
        }
    }
}

@Composable
fun VariantPickerScreen(vm: AppViewModel, songId: Long, pad: PaddingValues) {
    val songs by vm.songs.collectAsState()
    val song = songs.firstOrNull { it.id == songId }
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()

    if (song == null) {
        Column(Modifier.padding(pad)) {
            Header("Image variants") { vm.back() }
            Text("Song not found.", Modifier.padding(24.dp))
        }
        return
    }

    var title by remember(song.id) { mutableStateOf(song.title) }
    var artist by remember(song.id) { mutableStateOf(song.artist.takeIf { it != "Unknown artist" } ?: "") }
    var query by remember(song.id) { mutableStateOf(song.title to (song.artist.takeIf { it != "Unknown artist" } ?: "")) }
    val online = remember(song.id, query) { mutableStateListOf<Bitmap>() }
    var loading by remember(song.id, query) { mutableStateOf(true) }
    var original by remember(song.id) { mutableStateOf<Bitmap?>(null) }
    var message by remember(song.id) { mutableStateOf<String?>(null) }

    LaunchedEffect(song.id) { original = withContext(Dispatchers.IO) { embeddedArt(ctx, song) } }
    LaunchedEffect(song.id, query) {
        loading = true
        CoverFetcher.variants(query.first, query.second).collect { online.add(it) }
        loading = false
    }

    fun choose(label: String, work: () -> Unit) {
        scope.launch {
            withContext(Dispatchers.IO) { work() }
            vm.onCoverChanged(song.id)
            message = "Cover changed: $label"
        }
    }

    val gallery = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) scope.launch {
            val bmp = withContext(Dispatchers.IO) { decodeScaled(ctx, uri) }
            if (bmp != null) choose("your image") { CoverStore.setImage(ctx, song, bmp) }
            else message = "Couldn't open that image."
        }
    }

    Column(Modifier.padding(pad)) {
        Header(song.title) { vm.back() }
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            contentPadding = PaddingValues(16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item(span = { GridItemSpan(maxLineSpan) }) {
                Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Current cover", style = MaterialTheme.typography.labelLarge)
                    SongArt(song, 140.dp, corner = 20.dp)
                    message?.let { Text(it, color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodySmall) }
                }
            }
            item(span = { GridItemSpan(maxLineSpan) }) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        "Wrong results? Fix the title or artist and search again.",
                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    OutlinedTextField(title, { title = it }, label = { Text("Title") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(artist, { artist = it }, label = { Text("Artist") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { query = title.trim() to artist.trim() }) { Text("Search online") }
                        OutlinedButton(onClick = {
                            gallery.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                        }) { Text("From gallery") }
                    }
                }
            }
            original?.let { bmp ->
                item { Tile("Original (from file)", { choose("original") { CoverStore.reset(ctx, song) } }) { Pic(bmp) } }
            }
            item {
                Tile("Generated", { choose("generated") { CoverStore.setGenerated(ctx, song) } }) {
                    GeneratedCover(song, Modifier.fillMaxSize())
                }
            }
            items(online.size) { i ->
                val bmp = online[i]
                Tile("Online ${i + 1}", { choose("online ${i + 1}") { CoverStore.setImage(ctx, song, bmp) } }) { Pic(bmp) }
            }
            if (loading) item(span = { GridItemSpan(maxLineSpan) }) {
                Row(Modifier.fillMaxWidth().padding(8.dp), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
                    Spacer(Modifier.width(10.dp))
                    Text("Looking for covers…", style = MaterialTheme.typography.bodySmall)
                }
            } else if (online.isEmpty()) item(span = { GridItemSpan(maxLineSpan) }) {
                Text(
                    "No online covers found. Try a different title or artist.",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

@Composable
private fun Pic(bmp: Bitmap) =
    Image(bmp.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)

@Composable
private fun Tile(label: String, onClick: () -> Unit, content: @Composable BoxScope.() -> Unit) {
    Column(Modifier.clip(RoundedCornerShape(16.dp)).clickable(onClick = onClick)) {
        Box(Modifier.fillMaxWidth().aspectRatio(1f).clip(RoundedCornerShape(16.dp)), content = content)
        Text(label, Modifier.padding(top = 4.dp), style = MaterialTheme.typography.labelMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

private fun decodeScaled(ctx: Context, uri: Uri, max: Int = 1024): Bitmap? {
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
    var sample = 1
    while (bounds.outWidth / sample > max * 2 || bounds.outHeight / sample > max * 2) sample *= 2
    return ctx.contentResolver.openInputStream(uri)?.use {
        BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample })
    }
}
