package com.wavetunes

import android.app.Application
import android.content.ComponentName
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.wavetunes.data.*
import com.wavetunes.playback.PlaybackService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.combine
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import com.wavetunes.ui.bumpCovers
import com.wavetunes.ui.resetCoverCache
import com.wavetunes.ui.songBitmap
import android.net.Uri
import kotlinx.coroutines.withContext
import java.util.UUID

class AppViewModel(app: Application) : AndroidViewModel(app) {
    val store = Store(app).also { it.migrateCovers() }

    val songs = MutableStateFlow<List<Song>>(emptyList())
    val playlists = MutableStateFlow(store.loadPlaylists())
    val layout = MutableStateFlow(store.loadLayout())
    val screen = MutableStateFlow<Screen>(Screen.Home)
    val editing = MutableStateFlow(false)
    val nowPlaying = MutableStateFlow<Song?>(null)
    val isPlaying = MutableStateFlow(false)
    val shuffleOn = MutableStateFlow(false)
    val micGranted = MutableStateFlow(false)
    val importUi = MutableStateFlow(ImportUi())
    val lyrics = MutableStateFlow<SongLyrics?>(null)
    val lyricsLoading = MutableStateFlow(false)
    private var lyricsFor: Long? = null

    // ---- settings + album color ----
    val settings = MutableStateFlow(store.loadSettings().also { CoverRules.yearByArtist = it.yearRules })
    /** Raw dominant color of the playing album's cover (ARGB). */
    private val albumColor = MutableStateFlow<Int?>(null)
    /** Album color after your "color rules" (Settings). Drives the theme, wallpaper and visualizer. */
    val seed = MutableStateFlow<Int?>(null)

    /** Your own wallpaper image matching the playing album's color (path?version), if you set one. */
    val wallpaperPath = MutableStateFlow<String?>(null)
    private val wallpaperTick = MutableStateFlow(0)

    init {
        viewModelScope.launch {
            combine(albumColor, settings, wallpaperTick) { c, s, _ -> c to s }.collect { (c, s) ->
                val argb = c?.let { applyHueRule(it, s) }
                seed.value = argb
                // your wallpaper for this album's color family (the cover's real color, before color rules)
                val family = c?.let { familyOf(Color(it)) }
                val file = family?.takeIf { it in s.wallpapers }
                    ?.let { WallpaperStore.file(getApplication<Application>(), it) }?.takeIf { it.exists() }
                val key = file?.let { "${it.path}?${it.lastModified()}" }
                wallpaperPath.value = key
                if (argb != null) store.saveWallpaper(argb, s, key)          // live wallpaper follows
            }
        }
    }

    fun setWallpaper(fam: HueFamily, uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            val name = WallpaperStore.save(getApplication<Application>(), fam, uri) ?: return@launch
            updateSettings { it.copy(wallpapers = it.wallpapers + (fam to name)) }
            wallpaperTick.value++
        }
    }

    fun clearWallpaper(fam: HueFamily) {
        viewModelScope.launch(Dispatchers.IO) {
            WallpaperStore.file(getApplication<Application>(), fam).delete()
            updateSettings { it.copy(wallpapers = it.wallpapers - fam) }
            wallpaperTick.value++
        }
    }

    private fun applyHueRule(argb: Int, s: AppSettings) = s.hueOverrides[familyOf(Color(argb))] ?: argb
    private val lyricCache = HashMap<Long, SongLyrics>()

    private var controller: MediaController? = null
    private val listener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) = sync()
        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) = sync()
        override fun onShuffleModeEnabledChanged(shuffleModeEnabled: Boolean) { this@AppViewModel.shuffleOn.value = shuffleModeEnabled }
    }

    init {
        val token = SessionToken(app, ComponentName(app, PlaybackService::class.java))
        val future = MediaController.Builder(app, token).buildAsync()
        future.addListener({
            controller = future.get().also { it.addListener(listener) }
            sync()
        }, ContextCompat.getMainExecutor(app))
        refreshSongs()
    }

    private fun sync() {
        val c = controller ?: return
        isPlaying.value = c.isPlaying
        shuffleOn.value = c.shuffleModeEnabled
        val id = c.currentMediaItem?.mediaId?.toLongOrNull()
        nowPlaying.value = songs.value.firstOrNull { it.id == id }
        val song = nowPlaying.value
        if (song?.id != lyricsFor) { lyricsFor = song?.id; loadLyrics(song); updateAlbumColor(song) }
    }

    private fun loadLyrics(song: Song?) {
        lyrics.value = null
        lyricsLoading.value = false
        if (song == null) return
        lyricCache[song.id]?.let { lyrics.value = it; return }
        lyricsLoading.value = true
        viewModelScope.launch {
            val l = LyricsApi.fetch(song)
            if (l != null) lyricCache[song.id] = l
            if (nowPlaying.value?.id == song.id) { lyrics.value = l; lyricsLoading.value = false }
        }
    }

    fun refreshSongs() {
        viewModelScope.launch(Dispatchers.IO) {
            songs.value = runCatching { LocalMusic.scan(getApplication()) }.getOrDefault(emptyList())
            withContext(Dispatchers.Main) { sync() }
        }
    }

    private fun updateAlbumColor(song: Song?) {
        if (song == null) return                       // keep the last color when nothing is playing
        viewModelScope.launch(Dispatchers.IO) {
            val bmp = songBitmap(getApplication<Application>(), song)
            albumColor.value = (bmp?.let { dominantColor(it) } ?: generatedColor(song)).toArgb()
        }
    }

    /** Call after a song's cover was changed in Image variants. */
    fun onCoverChanged(id: Long) {
        bumpCovers(id)
        nowPlaying.value?.takeIf { it.id == id }?.let { song ->
            updateAlbumColor(song)
            // new artwork address -> the notification / control center reloads the cover
            controller?.let { c -> c.replaceMediaItem(c.currentMediaItemIndex, song.toMediaItem()) }
        }
    }

    fun updateSettings(f: (AppSettings) -> AppSettings) {
        val old = settings.value
        val new = f(old)
        settings.value = new
        store.saveSettings(new)
        if (new.yearRules != old.yearRules) {
            // rules changed: forget automatic covers so they are looked up again with the new rules
            CoverRules.yearByArtist = new.yearRules
            viewModelScope.launch(Dispatchers.IO) {
                CoverFetcher.clearAutoCache(getApplication<Application>())
                withContext(Dispatchers.Main) { resetCoverCache(); nowPlaying.value?.let { updateAlbumColor(it) } }
            }
        }
    }

    fun back() {
        screen.value = when (screen.value) {
            Screen.Variants -> Screen.Settings
            is Screen.VariantPicker -> Screen.Variants
            else -> Screen.Home
        }
    }

    // ---- playlists (no Spotify needed) ----
    private fun setPlaylists(l: List<LocalPlaylist>) { playlists.value = l; store.savePlaylists(l) }
    fun createPlaylist(name: String, firstSongId: Long? = null): String {
        val id = UUID.randomUUID().toString()
        setPlaylists(playlists.value + LocalPlaylist(id, name.trim().ifEmpty { "New playlist" }, listOfNotNull(firstSongId)))
        return id
    }
    fun addToPlaylist(pid: String, songId: Long) = addManyToPlaylist(pid, listOf(songId))
    fun addManyToPlaylist(pid: String, ids: List<Long>) = setPlaylists(playlists.value.map {
        if (it.id == pid) it.copy(songIds = it.songIds + ids.filter { id -> id !in it.songIds }) else it
    })
    fun removeFromPlaylist(pid: String, songId: Long) = setPlaylists(playlists.value.map {
        if (it.id == pid) it.copy(songIds = it.songIds - songId) else it
    })
    fun deletePlaylist(pid: String) = setPlaylists(playlists.value.filter { it.id != pid })

    // ---- playback ----
    fun positionMs(): Long = controller?.currentPosition ?: 0L
    fun seekToMs(ms: Long) { controller?.seekTo(ms) }
    fun play(list: List<Song>, index: Int) {
        val c = controller ?: return
        if (list.isEmpty()) return
        c.setMediaItems(list.map { it.toMediaItem() }, index, 0L)
        c.prepare(); c.play()
    }
    fun playShuffled(list: List<Song> = songs.value) = play(list.shuffled(), 0)
    fun toggleShuffle() { controller?.let { it.shuffleModeEnabled = !it.shuffleModeEnabled } }
    fun togglePlay() { controller?.let { if (it.isPlaying) it.pause() else it.play() } }
    fun next() { controller?.seekToNextMediaItem() }
    fun prev() {
        val c = controller ?: return
        if (c.currentPosition > 3000) c.seekTo(0) else c.seekToPreviousMediaItem()
    }
    fun seekTo(fraction: Float) {
        val c = controller ?: return
        if (c.duration > 0) c.seekTo((c.duration * fraction).toLong())
    }
    fun progress(): Float {
        val c = controller ?: return 0f
        return if (c.duration > 0) (c.currentPosition.toFloat() / c.duration).coerceIn(0f, 1f) else 0f
    }

    // ---- home layout ----
    private fun setLayout(l: List<HomeBlock>) { layout.value = l; store.saveLayout(l) }
    fun moveBlock(i: Int, delta: Int) {
        val l = layout.value.toMutableList(); val j = i + delta
        if (j !in l.indices) return
        l.add(j, l.removeAt(i)); setLayout(l)
    }
    fun toggleBlock(i: Int) = setLayout(layout.value.mapIndexed { k, b -> if (k == i) b.copy(visible = !b.visible) else b })
    fun resizeBlock(i: Int) = setLayout(layout.value.mapIndexed { k, b -> if (k == i) b.copy(full = !b.full) else b })

    // ---- link import (no login) ----
    /** Reads a public Spotify playlist link, matches tracks to songs on this phone, saves a local playlist. */
    fun importLink(link: String) {
        val id = SpotifyEmbed.playlistId(link)
        if (id == null) {
            importUi.value = ImportUi(message = "That doesn't look like a Spotify playlist link.")
            return
        }
        viewModelScope.launch {
            importUi.value = ImportUi(busy = true)
            try {
                val (name, tracks) = SpotifyEmbed.fetch(id)
                val (found, missing) = Matcher.match(tracks, songs.value)
                if (found.isNotEmpty()) {
                    playlists.value = playlists.value + LocalPlaylist(UUID.randomUUID().toString(), name, found.map { it.id })
                    store.savePlaylists(playlists.value)
                }
                importUi.value = ImportUi(
                    message = "Matched ${found.size} of ${tracks.size} songs from \"$name\"." +
                        if (found.isEmpty()) " Nothing was saved." else "",
                    missing = missing.map { it.label },
                )
            } catch (e: Exception) {
                importUi.value = ImportUi(message = e.message ?: "Import failed.")
            }
        }
    }

    override fun onCleared() { controller?.release() }
}
