package com.wavetunes

import android.app.Application
import android.content.ComponentName
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.wavetunes.data.*
import com.wavetunes.playback.PlaybackService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import java.util.UUID

class AppViewModel(app: Application) : AndroidViewModel(app) {
    val store = Store(app)

    val songs = MutableStateFlow<List<Song>>(emptyList())
    val playlists = MutableStateFlow(store.loadPlaylists())
    val layout = MutableStateFlow(store.loadLayout())
    val screen = MutableStateFlow<Screen>(Screen.Home)
    val editing = MutableStateFlow(false)
    val nowPlaying = MutableStateFlow<Song?>(null)
    val isPlaying = MutableStateFlow(false)
    val micGranted = MutableStateFlow(false)
    val importUi = MutableStateFlow(ImportUi())

    private var controller: MediaController? = null
    private val listener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) = sync()
        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) = sync()
    }

    init {
        val token = SessionToken(app, ComponentName(app, PlaybackService::class.java))
        val future = MediaController.Builder(app, token).buildAsync()
        future.addListener({
            controller = future.get().also { it.addListener(listener) }
            sync()
        }, ContextCompat.getMainExecutor(app))
        refreshSongs()
    }

    private fun sync() {
        val c = controller ?: return
        isPlaying.value = c.isPlaying
        val id = c.currentMediaItem?.mediaId?.toLongOrNull()
        nowPlaying.value = songs.value.firstOrNull { it.id == id }
    }

    fun refreshSongs() {
        viewModelScope.launch(Dispatchers.IO) {
            songs.value = runCatching { LocalMusic.scan(getApplication()) }.getOrDefault(emptyList())
            sync()
        }
    }

    // ---- playback ----
    fun play(list: List<Song>, index: Int) {
        val c = controller ?: return
        if (list.isEmpty()) return
        c.setMediaItems(list.map { it.toMediaItem() }, index, 0L)
        c.prepare(); c.play()
    }
    fun playShuffled() = play(songs.value.shuffled(), 0)
    fun togglePlay() { controller?.let { if (it.isPlaying) it.pause() else it.play() } }
    fun next() { controller?.seekToNextMediaItem() }
    fun prev() {
        val c = controller ?: return
        if (c.currentPosition > 3000) c.seekTo(0) else c.seekToPreviousMediaItem()
    }
    fun seekTo(fraction: Float) {
        val c = controller ?: return
        if (c.duration > 0) c.seekTo((c.duration * fraction).toLong())
    }
    fun progress(): Float {
        val c = controller ?: return 0f
        return if (c.duration > 0) (c.currentPosition.toFloat() / c.duration).coerceIn(0f, 1f) else 0f
    }

    // ---- home layout ----
    private fun setLayout(l: List<HomeBlock>) { layout.value = l; store.saveLayout(l) }
    fun moveBlock(i: Int, delta: Int) {
        val l = layout.value.toMutableList(); val j = i + delta
        if (j !in l.indices) return
        l.add(j, l.removeAt(i)); setLayout(l)
    }
    fun toggleBlock(i: Int) = setLayout(layout.value.mapIndexed { k, b -> if (k == i) b.copy(visible = !b.visible) else b })
    fun resizeBlock(i: Int) = setLayout(layout.value.mapIndexed { k, b -> if (k == i) b.copy(full = !b.full) else b })

    // ---- link import (no login) ----
    /** Reads a public Spotify playlist link, matches tracks to songs on this phone, saves a local playlist. */
    fun importLink(link: String) {
        val id = SpotifyEmbed.playlistId(link)
        if (id == null) {
            importUi.value = ImportUi(message = "That doesn't look like a Spotify playlist link.")
            return
        }
        viewModelScope.launch {
            importUi.value = ImportUi(busy = true)
            try {
                val (name, tracks) = SpotifyEmbed.fetch(id)
                val (found, missing) = Matcher.match(tracks, songs.value)
                if (found.isNotEmpty()) {
                    playlists.value = playlists.value + LocalPlaylist(UUID.randomUUID().toString(), name, found.map { it.id })
                    store.savePlaylists(playlists.value)
                }
                importUi.value = ImportUi(
                    message = "Matched ${found.size} of ${tracks.size} songs from \"$name\"." +
                        if (found.isEmpty()) " Nothing was saved." else "",
                    missing = missing.map { it.label },
                )
            } catch (e: Exception) {
                importUi.value = ImportUi(message = e.message ?: "Import failed.")
            }
        }
    }

    override fun onCleared() { controller?.release() }
}
