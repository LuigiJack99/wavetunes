package com.wavetunes

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import com.wavetunes.data.Screen
import com.wavetunes.playback.PlaybackService
import com.wavetunes.ui.*
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    private val vm: AppViewModel by viewModels()

    private val permissions = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        vm.refreshSongs()
        vm.micGranted.value = hasMic()
    }

    private fun hasMic() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        vm.micGranted.value = hasMic()
        permissions.launch(buildList {
            if (Build.VERSION.SDK_INT >= 33) {
                add(Manifest.permission.READ_MEDIA_AUDIO); add(Manifest.permission.POST_NOTIFICATIONS)
            } else add(Manifest.permission.READ_EXTERNAL_STORAGE)
            add(Manifest.permission.RECORD_AUDIO)
        }.toTypedArray())

        setContent {
            WaveTunesTheme {
                val screen by vm.screen.collectAsState()
                val now by vm.nowPlaying.collectAsState()
                val playing by vm.isPlaying.collectAsState()
                val mic by vm.micGranted.collectAsState()
                val session by PlaybackService.audioSession.collectAsState()
                val bars by rememberBars(session, mic, playing)
                var progress by remember { mutableFloatStateOf(0f) }
                LaunchedEffect(Unit) { while (true) { progress = vm.progress(); delay(100) } }

                BackHandler(enabled = screen != Screen.Home) { vm.screen.value = Screen.Home }

                Scaffold(
                    bottomBar = {
                        EqualizerBar(
                            song = now, isPlaying = playing, progress = progress, bars = bars,
                            onSeek = vm::seekTo, onPrev = vm::prev, onPlayPause = vm::togglePlay, onNext = vm::next,
                        )
                    }
                ) { pad ->
                    Box(Modifier.fillMaxSize()) {
                        when (val s = screen) {
                            Screen.Home -> HomeScreen(vm, pad)
                            Screen.Library -> LibraryScreen(vm, pad)
                            Screen.Import -> ImportScreen(vm, pad)
                            is Screen.Playlist -> PlaylistScreen(vm, s.id, pad)
                        }
                    }
                }
            }
        }
    }
}
