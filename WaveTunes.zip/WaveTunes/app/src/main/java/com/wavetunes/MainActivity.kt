package com.wavetunes

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.core.content.ContextCompat
import com.wavetunes.data.Screen
import com.wavetunes.data.brighten
import com.wavetunes.playback.PlaybackService
import com.wavetunes.ui.*
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    private val vm: AppViewModel by viewModels()

    private val permissions = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        vm.refreshSongs()
        vm.micGranted.value = hasMic()
    }

    private fun hasMic() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        vm.micGranted.value = hasMic()
        permissions.launch(buildList {
            if (Build.VERSION.SDK_INT >= 33) {
                add(Manifest.permission.READ_MEDIA_AUDIO); add(Manifest.permission.POST_NOTIFICATIONS)
            } else add(Manifest.permission.READ_EXTERNAL_STORAGE)
            add(Manifest.permission.RECORD_AUDIO)
        }.toTypedArray())

        setContent {
            val settings by vm.settings.collectAsState()
            val screen by vm.screen.collectAsState()
            val now by vm.nowPlaying.collectAsState()
            val playing by vm.isPlaying.collectAsState()
            val shuffle by vm.shuffleOn.collectAsState()
            val mic by vm.micGranted.collectAsState()
            val seedArgb by vm.seed.collectAsState()
            val wp by vm.wallpaperPath.collectAsState()
            val seed = seedArgb?.let { Color(it) }
            val session by PlaybackService.audioSession.collectAsState()
            val bars by rememberBars(session, mic, playing, settings.barCount)
            val art by rememberSongBitmap(now)
            var progress by remember { mutableFloatStateOf(0f) }
            var pos by remember { mutableLongStateOf(0L) }
            LaunchedEffect(Unit) { while (true) { progress = vm.progress(); pos = vm.positionMs(); delay(100) } }

            BackHandler(enabled = screen != Screen.Home) { vm.back() }

            WaveTunesTheme(settings, seed) {
                val accent = seed?.let(::brighten) ?: MaterialTheme.colorScheme.primary
                Box(Modifier.fillMaxSize()) {
                    AlbumBackground(seed, art, settings, wp, Modifier.matchParentSize())
                    Scaffold(
                        containerColor = Color.Transparent,
                        bottomBar = {
                            EqualizerBar(
                                song = now, isPlaying = playing, progress = progress, bars = bars,
                                onSeek = vm::seekTo, onPrev = vm::prev, onPlayPause = vm::togglePlay, onNext = vm::next,
                                onLyrics = { vm.screen.value = if (screen == Screen.Lyrics) Screen.Home else Screen.Lyrics },
                                accentColor = accent,
                                shuffleOn = shuffle, onShuffle = vm::toggleShuffle,
                            )
                        }
                    ) { pad ->
                        AnimatedContent(
                            screen, Modifier.fillMaxSize(), label = "screen",
                            transitionSpec = {
                                (fadeIn(tween(220)) + slideInVertically(tween(220)) { it / 24 }) togetherWith fadeOut(tween(120))
                            },
                        ) { s ->
                            when (s) {
                                Screen.Home -> HomeScreen(vm, pad)
                                Screen.Library -> LibraryScreen(vm, pad)
                                Screen.Lyrics -> LyricsScreen(vm, pad, pos)
                                Screen.Import -> ImportScreen(vm, pad)
                                Screen.Settings -> SettingsScreen(vm, pad)
                                Screen.Variants -> VariantsScreen(vm, pad)
                                is Screen.VariantPicker -> VariantPickerScreen(vm, s.songId, pad)
                                is Screen.Playlist -> PlaylistScreen(vm, s.id, pad)
                            }
                        }
                    }
                }
            }
        }
    }

    // Pick up tag/cover edits made in another app
    override fun onStart() {
        super.onStart()
        vm.refreshSongs()
    }
}
