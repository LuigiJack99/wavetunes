package com.wavetunes.ui

import android.os.Build
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import com.wavetunes.data.AppSettings
import com.wavetunes.data.ColorSource
import com.wavetunes.data.ThemeMode

/**
 * Whole-app theme. Colors come from the playing album's cover (default), your wallpaper-based
 * Material You colors, or a custom color. Changes fade smoothly between songs.
 */
@Composable
fun WaveTunesTheme(settings: AppSettings, seed: Color?, content: @Composable () -> Unit) {
    val dark = when (settings.themeMode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }
    val ctx = LocalContext.current
    val target = when (settings.colorSource) {
        ColorSource.ALBUM -> seed
        ColorSource.CUSTOM -> Color(settings.customColor)
        ColorSource.SYSTEM -> null
    }
    val animated by animateColorAsState(target ?: Color.Gray, tween(700), label = "themeSeed")
    val scheme = when {
        target != null -> schemeFromSeed(animated, dark)
        Build.VERSION.SDK_INT >= 31 -> if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
        dark -> darkColorScheme()
        else -> lightColorScheme()
    }
    MaterialTheme(colorScheme = scheme, content = content)
}

/** Builds a full Material 3 palette around one color. Gray seeds give gray palettes. */
fun schemeFromSeed(seed: Color, dark: Boolean): ColorScheme {
    val hsv = FloatArray(3)
    android.graphics.Color.colorToHSV(seed.toArgb(), hsv)
    val h = hsv[0]
    val neutral = hsv[1] < 0.15f
    fun c(hue: Float, sat: Float, v: Float) =
        Color.hsv(((hue % 360f) + 360f) % 360f, if (neutral) 0f else sat.coerceIn(0f, 1f), v.coerceIn(0f, 1f))

    return if (dark) darkColorScheme(
        primary = c(h, 0.5f, 0.95f), onPrimary = c(h, 0.8f, 0.2f),
        primaryContainer = c(h, 0.6f, 0.38f), onPrimaryContainer = c(h, 0.15f, 0.95f),
        secondary = c(h + 25, 0.35f, 0.85f), onSecondary = c(h + 25, 0.8f, 0.2f),
        secondaryContainer = c(h + 25, 0.4f, 0.32f), onSecondaryContainer = c(h + 25, 0.1f, 0.93f),
        tertiary = c(h + 60, 0.45f, 0.9f), onTertiary = c(h + 60, 0.8f, 0.2f),
        tertiaryContainer = c(h + 60, 0.5f, 0.33f), onTertiaryContainer = c(h + 60, 0.1f, 0.93f),
        background = c(h, 0.3f, 0.09f), onBackground = c(h, 0.06f, 0.93f),
        surface = c(h, 0.3f, 0.09f), onSurface = c(h, 0.06f, 0.93f),
        surfaceVariant = c(h, 0.25f, 0.22f), onSurfaceVariant = c(h, 0.1f, 0.8f),
        surfaceTint = c(h, 0.5f, 0.95f),
        outline = c(h, 0.15f, 0.55f), outlineVariant = c(h, 0.25f, 0.3f),
        surfaceContainerLowest = c(h, 0.3f, 0.07f), surfaceContainerLow = c(h, 0.3f, 0.11f),
        surfaceContainer = c(h, 0.3f, 0.13f), surfaceContainerHigh = c(h, 0.3f, 0.17f),
        surfaceContainerHighest = c(h, 0.3f, 0.21f),
    ) else lightColorScheme(
        primary = c(h, 0.75f, 0.58f), onPrimary = Color.White,
        primaryContainer = c(h, 0.22f, 0.96f), onPrimaryContainer = c(h, 0.85f, 0.25f),
        secondary = c(h + 25, 0.5f, 0.5f), onSecondary = Color.White,
        secondaryContainer = c(h + 25, 0.18f, 0.95f), onSecondaryContainer = c(h + 25, 0.8f, 0.25f),
        tertiary = c(h + 60, 0.5f, 0.55f), onTertiary = Color.White,
        tertiaryContainer = c(h + 60, 0.2f, 0.95f), onTertiaryContainer = c(h + 60, 0.8f, 0.25f),
        background = c(h, 0.04f, 0.985f), onBackground = c(h, 0.2f, 0.12f),
        surface = c(h, 0.04f, 0.985f), onSurface = c(h, 0.2f, 0.12f),
        surfaceVariant = c(h, 0.1f, 0.9f), onSurfaceVariant = c(h, 0.2f, 0.3f),
        surfaceTint = c(h, 0.75f, 0.58f),
        outline = c(h, 0.1f, 0.5f), outlineVariant = c(h, 0.1f, 0.8f),
        surfaceContainerLowest = Color.White, surfaceContainerLow = c(h, 0.06f, 0.965f),
        surfaceContainer = c(h, 0.06f, 0.945f), surfaceContainerHigh = c(h, 0.06f, 0.925f),
        surfaceContainerHighest = c(h, 0.06f, 0.905f),
    )
}
