package com.wavetunes.ui

import android.media.audiofx.Visualizer
import androidx.compose.runtime.*
import kotlin.math.hypot
import kotlin.math.pow
import kotlin.math.sin

/**
 * Live spectrum bars (0..1). Uses the real audio via android.media.audiofx.Visualizer when the
 * mic permission is granted; otherwise falls back to an animated placeholder wave.
 */
@Composable
fun rememberBars(sessionId: Int, micGranted: Boolean, playing: Boolean, count: Int = 48): State<FloatArray> {
    val bars = remember(count) { mutableStateOf(FloatArray(count)) }
    var liveOk by remember { mutableStateOf(false) }

    DisposableEffect(sessionId, micGranted, count) {
        var viz: Visualizer? = null
        if (micGranted && sessionId != 0) {
            try {
                viz = Visualizer(sessionId).apply {
                    captureSize = Visualizer.getCaptureSizeRange()[1].coerceAtMost(1024)
                    setDataCaptureListener(object : Visualizer.OnDataCaptureListener {
                        override fun onWaveFormDataCapture(v: Visualizer?, w: ByteArray?, r: Int) {}
                        override fun onFftDataCapture(v: Visualizer?, fft: ByteArray, r: Int) {
                            val cur = fftToBars(fft, count)
                            val prev = bars.value
                            // fast attack, slow decay
                            bars.value = FloatArray(count) { i ->
                                if (cur[i] > prev[i]) cur[i] else prev[i] * 0.86f + cur[i] * 0.14f
                            }
                        }
                    }, Visualizer.getMaxCaptureRate() / 2, false, true)
                    enabled = true
                }
                liveOk = true
            } catch (e: Exception) {
                viz = null; liveOk = false
            }
        } else liveOk = false
        onDispose { viz?.enabled = false; viz?.release() }
    }

    LaunchedEffect(liveOk, playing, count) {
        if (liveOk) return@LaunchedEffect
        while (true) {
            withFrameNanos { t ->
                val s = t / 1_000_000_000.0
                val cur = bars.value
                bars.value = FloatArray(count) { i ->
                    val target = if (playing) {
                        ((0.35 + 0.3 * sin(s * 3 + i * 0.5) + 0.2 * sin(s * 5.3 + i * 1.3)).toFloat()
                            .coerceIn(0.05f, 1f)) * (1f - i / (count * 1.6f))
                    } else 0.04f
                    cur[i] + (target - cur[i]) * 0.2f
                }
            }
        }
    }
    return bars
}

private fun fftToBars(fft: ByteArray, count: Int): FloatArray {
    val bins = fft.size / 2 - 1                      // complex pairs after the DC/Nyquist header
    return FloatArray(count) { b ->
        val lo = bins.toFloat().pow(b.toFloat() / count).toInt().coerceAtLeast(1)
        val hi = bins.toFloat().pow((b + 1f) / count).toInt().coerceAtLeast(lo + 1).coerceAtMost(bins)
        var sum = 0f; var n = 0
        for (k in lo until hi) {
            val re = fft[2 * k].toFloat(); val im = fft[2 * k + 1].toFloat()
            sum += hypot(re, im); n++
        }
        val mag = if (n > 0) sum / n else 0f
        ((mag / 90f) * (1f + b * 0.04f)).coerceIn(0f, 1f)
    }
}
