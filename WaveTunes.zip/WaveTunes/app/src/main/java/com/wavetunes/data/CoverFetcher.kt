package com.wavetunes.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import okhttp3.HttpUrl
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.io.File
import java.io.IOException

/**
 * Finds cover art online for songs whose file has none. Looks the song up on MusicBrainz
 * (title + artist), then pulls the release's front cover from the Cover Art Archive.
 * Results are saved in app storage so each song is looked up once. Best effort: obscure
 * songs may not be found. MusicBrainz asks for max 1 request per second, so lookups are queued.
 */
object CoverFetcher {
    private val http = OkHttpClient()
    private val gate = Mutex()
    private var last = 0L

    suspend fun get(ctx: Context, song: Song): Bitmap? = withContext(Dispatchers.IO) {
        val dir = File(ctx.filesDir, "covers").apply { mkdirs() }
        val img = File(dir, "${song.id}.jpg")
        val none = File(dir, "${song.id}.none")
        if (img.exists()) return@withContext BitmapFactory.decodeFile(img.path)
        if (none.exists() || song.artist == "Unknown artist") return@withContext null

        val bytes: ByteArray? = try {
            gate.withLock {
                val wait = 1100 - (System.currentTimeMillis() - last)
                if (wait > 0) delay(wait)
                try { download(song) } finally { last = System.currentTimeMillis() }
            }
        } catch (e: IOException) {
            return@withContext null            // network problem: try again next time
        }
        if (bytes == null) { none.createNewFile(); return@withContext null }
        img.writeBytes(bytes)
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
    }

    private fun esc(s: String) = s.replace("\\", " ").replace("\"", " ")

    private fun call(url: HttpUrl): Pair<Int, ByteArray?> {
        val req = Request.Builder().url(url).header("User-Agent", "WaveTunes/1.0 (personal music player)").build()
        http.newCall(req).execute().use { r ->
            if (r.code == 503 || r.code == 429) throw IOException("rate limited")
            return r.code to (if (r.isSuccessful) r.body?.bytes() else null)
        }
    }

    private fun download(song: Song): ByteArray? {
        val artist = song.artist.replace(" & ", ",").substringBefore(",").trim()
        val q = "recording:\"${esc(song.title)}\" AND artist:\"${esc(artist)}\""
        val search = HttpUrl.Builder().scheme("https").host("musicbrainz.org").addPathSegments("ws/2/recording/")
            .addQueryParameter("query", q).addQueryParameter("fmt", "json").addQueryParameter("limit", "5").build()
        val body = call(search).second ?: return null
        val recs = JSONObject(String(body)).optJSONArray("recordings") ?: return null
        val ids = LinkedHashSet<String>()
        for (i in 0 until recs.length()) {
            val rels = recs.getJSONObject(i).optJSONArray("releases") ?: continue
            for (j in 0 until rels.length()) ids += rels.getJSONObject(j).getString("id")
        }
        for (id in ids.take(6)) {
            val (code, bytes) = call("https://coverartarchive.org/release/$id/front-500".toHttpUrl())
            if (code == 200 && bytes != null && bytes.size > 1000) return bytes
        }
        return null
    }
}
