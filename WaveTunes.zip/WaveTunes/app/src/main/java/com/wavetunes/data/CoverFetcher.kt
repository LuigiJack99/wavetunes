package com.wavetunes.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import okhttp3.HttpUrl
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException

/** "For this artist, prefer releases from this year" (e.g. weezer -> 2024 for re-recordings). */
object CoverRules {
    @Volatile var yearByArtist: Map<String, Int> = mapOf("weezer" to 2024)
}

/**
 * Finds cover art online (MusicBrainz lookup + Cover Art Archive images). Best effort.
 *
 * Only releases that really contain the song by that artist are used. Compilations, "Various
 * Artists" releases, DJ mixes and playlist-style titles ("Top Hits", "Workout Mix"...) are skipped,
 * and the original studio release is preferred, unless a year rule asks for a newer version.
 * MusicBrainz asks for max 1 request per second, so lookups are queued.
 */
object CoverFetcher {
    private val http = OkHttpClient()
    private val gate = Mutex()
    private var last = 0L

    private val brackets = Regex("\\(.*?\\)|\\[.*?]")
    private val junkChars = Regex("[^\\p{L}\\p{N}]")
    private val junkRecording = Regex("(?i)karaoke|tribute|made famous|originally performed|cover version|instrumental version")
    private val playlistTitle = Regex(
        "(?i)now that'?s what i call|greatest hits|best of|\\btop \\d+|essentials|playlist|workout|party|\\bhits\\b|" +
        "\\bchart|\\bmix(es)?\\b|\\bvol\\.? ?\\d+|collection|karaoke|tribute|#1|throwback|anthems|ultimate|\\d{4} hits"
    )

    private data class Candidate(val releaseId: String, val score: Int, val excluded: Boolean, val date: String)

    private fun firstArtist(song: Song) =
        song.artist.replace(" & ", ",").substringBefore(",").trim().takeIf { it != "Unknown artist" }.orEmpty()

    private fun normTitle(s: String) = s.lowercase().replace(brackets, "").substringBefore(" - ").replace(junkChars, "")
    private fun normName(s: String) = s.lowercase().replace(junkChars, "")

    /** Automatic cover for a song (best match), cached on disk. */
    suspend fun get(ctx: Context, song: Song): Bitmap? = withContext(Dispatchers.IO) {
        val dir = File(ctx.filesDir, "covers").apply { mkdirs() }
        val img = File(dir, "${song.id}.auto.jpg")
        val none = File(dir, "${song.id}.none")
        if (img.exists()) return@withContext BitmapFactory.decodeFile(img.path)
        if (none.exists() || firstArtist(song).isEmpty()) return@withContext null

        val bytes: ByteArray? = try {
            gate.withLock {
                throttle()
                try { download(song) } finally { last = System.currentTimeMillis() }
            }
        } catch (e: IOException) {
            return@withContext null            // network problem: try again next time
        }
        if (bytes == null) { none.createNewFile(); return@withContext null }
        img.writeBytes(bytes)
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
    }

    /** Forget all automatic lookups (used when cover rules change). Picks you made are kept. */
    fun clearAutoCache(ctx: Context) {
        File(ctx.filesDir, "covers").listFiles()?.forEach {
            if (it.name.endsWith(".auto.jpg") || it.name.endsWith(".none")) it.delete()
        }
    }

    /** Different covers for a title/artist, best match first, emitted as they download. */
    fun variants(title: String, artist: String, max: Int = 10): Flow<Bitmap> = flow {
        val ids: List<String> = try {
            gate.withLock {
                throttle()
                try { candidates(title, artist).map { it.releaseId } } finally { last = System.currentTimeMillis() }
            }
        } catch (e: IOException) { emptyList() }
        val seen = HashSet<Int>()
        var found = 0
        for (id in ids) {
            if (found >= max) break
            val (code, bytes) = try { call("https://coverartarchive.org/release/$id/front-500".toHttpUrl()) }
                                catch (e: IOException) { continue }
            if (code != 200 || bytes == null || bytes.size < 1000) continue
            if (!seen.add(bytes.contentHashCode())) continue      // same image on several releases
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size)?.let { emit(it); found++ }
        }
    }.flowOn(Dispatchers.IO)

    private suspend fun throttle() {
        val wait = 1100 - (System.currentTimeMillis() - last)
        if (wait > 0) delay(wait)
    }

    private fun esc(s: String) = s.replace("\\", " ").replace("\"", " ")

    private fun call(url: HttpUrl): Pair<Int, ByteArray?> {
        val req = Request.Builder().url(url).header("User-Agent", "WaveTunes/1.0 (personal music player)").build()
        http.newCall(req).execute().use { r ->
            if (r.code == 503 || r.code == 429) throw IOException("rate limited")
            return r.code to (if (r.isSuccessful) r.body?.bytes() else null)
        }
    }

    private fun creditMatches(credits: JSONArray?, wantArtist: String): Boolean {
        if (credits == null || wantArtist.length < 2) return false
        for (i in 0 until credits.length()) {
            val c = credits.optJSONObject(i) ?: continue
            val names = listOf(c.optString("name"), c.optJSONObject("artist")?.optString("name").orEmpty())
            if (names.any { n -> val x = normName(n); x.isNotEmpty() && (x.contains(wantArtist) || wantArtist.contains(x)) }) return true
        }
        return false
    }

    private fun isVariousArtists(credits: JSONArray?): Boolean {
        if (credits == null) return false
        for (i in 0 until credits.length()) {
            if (credits.optJSONObject(i)?.optString("name").orEmpty().equals("Various Artists", true)) return true
        }
        return false
    }

    /** Releases that contain this song by this artist, best first. Excluded ones are listed last. */
    private fun candidates(title: String, artist: String): List<Candidate> {
        val q = if (artist.isBlank()) "recording:\"${esc(title)}\""
                else "recording:\"${esc(title)}\" AND artist:\"${esc(artist)}\""
        val search = HttpUrl.Builder().scheme("https").host("musicbrainz.org").addPathSegments("ws/2/recording/")
            .addQueryParameter("query", q).addQueryParameter("fmt", "json").addQueryParameter("limit", "25").build()
        val body = call(search).second ?: return emptyList()
        val recs = JSONObject(String(body)).optJSONArray("recordings") ?: return emptyList()

        val wantTitle = normTitle(title)
        val wantArtist = normName(artist)
        val ruleYear = CoverRules.yearByArtist[artist.lowercase().trim()]
        val out = mutableListOf<Candidate>()
        val seen = HashSet<String>()

        for (i in 0 until recs.length()) {
            val rec = recs.getJSONObject(i)
            val recTitle = rec.optString("title")
            if (normTitle(recTitle) != wantTitle) continue                       // a different song
            if (junkRecording.containsMatchIn(recTitle) || junkRecording.containsMatchIn(rec.optString("disambiguation"))) continue
            if (wantArtist.isNotEmpty() && !creditMatches(rec.optJSONArray("artist-credit"), wantArtist)) continue  // someone else's version
            val rels = rec.optJSONArray("releases") ?: continue
            for (j in 0 until rels.length()) {
                val r = rels.getJSONObject(j)
                val id = r.optString("id")
                if (id.isEmpty() || !seen.add(id)) continue

                val credits = r.optJSONArray("artist-credit")
                val rg = r.optJSONObject("release-group")
                val primary = rg?.optString("primary-type").orEmpty()
                val secondary = rg?.optJSONArray("secondary-types")?.let { a -> List(a.length()) { a.optString(it) } }.orEmpty()
                val status = r.optString("status")
                val relTitle = r.optString("title")
                val date = r.optString("date")

                var score = 0
                var excluded = false
                if (status == "Official") score += 3 else if (status.isNotEmpty()) score -= 3
                when (primary) { "Album", "Single", "EP" -> score += 2; "" -> {}; else -> score -= 2 }
                for (t in secondary) when (t) {
                    "Compilation", "DJ-mix", "Mixtape/Street", "Interview", "Audiobook", "Spokenword" -> excluded = true
                    "Live", "Demo", "Remix" -> score -= 4
                    "Soundtrack" -> score -= 1
                }
                if (isVariousArtists(credits)) excluded = true
                if (credits != null && wantArtist.isNotEmpty() && !creditMatches(credits, wantArtist)) excluded = true
                if (playlistTitle.containsMatchIn(relTitle) &&
                    !(wantArtist.isNotEmpty() && creditMatches(credits, wantArtist))) excluded = true
                if (ruleYear != null && date.startsWith(ruleYear.toString())) score += 50   // e.g. Weezer 2024 re-recording
                out += Candidate(id, score, excluded, date)
            }
        }
        // good ones first, then highest score, then earliest release (the original)
        return out.sortedWith(compareBy<Candidate>({ it.excluded }, { -it.score }, { it.date.ifEmpty { "9999" } }))
    }

    private fun download(song: Song): ByteArray? {
        val good = candidates(song.title, firstArtist(song)).filter { !it.excluded }.take(6)
        for (c in good) {
            val (code, bytes) = call("https://coverartarchive.org/release/${c.releaseId}/front-500".toHttpUrl())
            if (code == 200 && bytes != null && bytes.size > 1000) return bytes
        }
        return null
    }
}
