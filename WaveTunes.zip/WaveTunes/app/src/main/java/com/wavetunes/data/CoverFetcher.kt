package com.wavetunes.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import okhttp3.HttpUrl
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.io.File
import java.io.IOException

/**
 * Finds cover art online (MusicBrainz lookup + Cover Art Archive images). Best effort.
 * MusicBrainz asks for max 1 request per second, so lookups are queued.
 */
object CoverFetcher {
    private val http = OkHttpClient()
    private val gate = Mutex()
    private var last = 0L

    private fun firstArtist(song: Song) =
        song.artist.replace(" & ", ",").substringBefore(",").trim().takeIf { it != "Unknown artist" }.orEmpty()

    /** Automatic cover for a song (first match), cached on disk. */
    suspend fun get(ctx: Context, song: Song): Bitmap? = withContext(Dispatchers.IO) {
        val dir = File(ctx.filesDir, "covers").apply { mkdirs() }
        val img = File(dir, "${song.id}.jpg")
        val none = File(dir, "${song.id}.none")
        if (img.exists()) return@withContext BitmapFactory.decodeFile(img.path)
        if (none.exists() || firstArtist(song).isEmpty()) return@withContext null

        val bytes: ByteArray? = try {
            gate.withLock {
                throttle()
                try { download(song) } finally { last = System.currentTimeMillis() }
            }
        } catch (e: IOException) {
            return@withContext null            // network problem: try again next time
        }
        if (bytes == null) { none.createNewFile(); return@withContext null }
        img.writeBytes(bytes)
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
    }

    /** All different covers found for a title/artist, emitted one by one as they download. */
    fun variants(title: String, artist: String, max: Int = 10): Flow<Bitmap> = flow {
        val ids: Set<String> = try {
            gate.withLock {
                throttle()
                try { releaseIds(title, artist) } finally { last = System.currentTimeMillis() }
            }
        } catch (e: IOException) { emptySet() }
        val seen = HashSet<Int>()
        var found = 0
        for (id in ids) {
            if (found >= max) break
            val (code, bytes) = try { call("https://coverartarchive.org/release/$id/front-500".toHttpUrl()) }
                                catch (e: IOException) { continue }
            if (code != 200 || bytes == null || bytes.size < 1000) continue
            if (!seen.add(bytes.contentHashCode())) continue      // same image on several releases
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size)?.let { emit(it); found++ }
        }
    }.flowOn(Dispatchers.IO)

    private suspend fun throttle() {
        val wait = 1100 - (System.currentTimeMillis() - last)
        if (wait > 0) delay(wait)
    }

    private fun esc(s: String) = s.replace("\\", " ").replace("\"", " ")

    private fun call(url: HttpUrl): Pair<Int, ByteArray?> {
        val req = Request.Builder().url(url).header("User-Agent", "WaveTunes/1.0 (personal music player)").build()
        http.newCall(req).execute().use { r ->
            if (r.code == 503 || r.code == 429) throw IOException("rate limited")
            return r.code to (if (r.isSuccessful) r.body?.bytes() else null)
        }
    }

    private fun releaseIds(title: String, artist: String): Set<String> {
        val q = if (artist.isBlank()) "recording:\"${esc(title)}\""
                else "recording:\"${esc(title)}\" AND artist:\"${esc(artist)}\""
        val search = HttpUrl.Builder().scheme("https").host("musicbrainz.org").addPathSegments("ws/2/recording/")
            .addQueryParameter("query", q).addQueryParameter("fmt", "json").addQueryParameter("limit", "10").build()
        val body = call(search).second ?: return emptySet()
        val recs = JSONObject(String(body)).optJSONArray("recordings") ?: return emptySet()
        val ids = LinkedHashSet<String>()
        for (i in 0 until recs.length()) {
            val rels = recs.getJSONObject(i).optJSONArray("releases") ?: continue
            for (j in 0 until rels.length()) ids += rels.getJSONObject(j).getString("id")
        }
        return ids
    }

    private fun download(song: Song): ByteArray? {
        for (id in releaseIds(song.title, firstArtist(song)).take(6)) {
            val (code, bytes) = call("https://coverartarchive.org/release/$id/front-500".toHttpUrl())
            if (code == 200 && bytes != null && bytes.size > 1000) return bytes
        }
        return null
    }
}
